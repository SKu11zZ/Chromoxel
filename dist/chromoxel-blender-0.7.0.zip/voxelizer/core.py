"""Geometry and data-safety core for Textured Voxelizer MVP.

The public functions in this module contain no UI state.  They build realized
cube meshes, tag only add-on-owned outputs, and refuse name collisions.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
import struct
from bisect import bisect_left, bisect_right
from collections import Counter, OrderedDict
from contextlib import contextmanager
from dataclasses import dataclass, field
from itertools import product
from typing import Iterable, Iterator, Optional

import bmesh
import bpy
from mathutils import Vector
from mathutils.bvhtree import BVHTree


TOOL_ID = "org.openai.textured_voxelizer_mvp"
TOOL_TAG = "_textured_voxelizer_tool"
KIND_TAG = "_textured_voxelizer_kind"
SOURCE_TAG = "_textured_voxelizer_source"
PREVIEW_KIND = "preview"
BAKE_KIND = "bake"
HELPER_KIND = "watertight_helper"
COLOUR_ATTRIBUTE = "voxel_color"
SIZE_ATTRIBUTE = "voxel_size"
EXTENT_ATTRIBUTE = "voxel_extent"
LEVEL_ATTRIBUTE = "voxel_level"
MATERIAL_NAME = ".BTVM_voxel_color"
SOURCE_SIGNATURE_TAG = "_textured_voxelizer_source_signature"
REPAIR_SIZE_TAG = "_textured_voxelizer_repair_voxel_size"
SOURCE_SYMMETRY_TAG = "_textured_voxelizer_source_symmetry"
HELPER_SYMMETRY_TAG = "_textured_voxelizer_helper_symmetry"
SAMPLING_DIAGNOSTICS_TAG = "_textured_voxelizer_sampling_diagnostics"
MAX_GRID_SAMPLES = 1_500_000
MAX_VOXELS = 250_000
DEFAULT_CACHE_MEMORY_MB = 128
DEFAULT_CHUNK_SIZE = 4096
SYMMETRY_RELATIVE_TOLERANCE = 1.0e-6
SYMMETRY_ABSOLUTE_FLOOR = 1.0e-7
SYMMETRY_SCHEMA_VERSION = 2
ADAPTIVE_SCHEMA_VERSION = 2
ADAPTIVE_CELL_AXIS_MARGIN = 0.10
ADAPTIVE_PLANAR_NORMAL_ALIGNMENT = 0.95
_AXIS_NAMES = ("X", "Y", "Z")
_LAST_SAMPLING_DIAGNOSTICS: dict[int, dict[str, object]] = {}
_SAMPLE_CACHE: OrderedDict[str, dict[str, object]] = OrderedDict()
_SAMPLE_CACHE_BYTES = 0


class VoxelizerError(RuntimeError):
    """A concise validation failure suitable for an operator report."""


@dataclass(frozen=True)
class SamplingProgress:
    """One resumable sampling progress update."""

    phase: str
    completed: int
    total: int
    message: str

    @property
    def fraction(self) -> float:
        if self.total <= 0:
            return 0.0
        return max(0.0, min(1.0, self.completed / self.total))


@dataclass
class VoxelSampleResult:
    """Voxel samples with backward-compatible four-value unpacking.

    Chromoxel 0.5 callers unpacked ``centres, colours, count, used_image``.
    Keeping that iterator contract lets old scripts continue to run while 0.6
    carries the per-cell size and refinement level required by adaptive output.
    """

    centres: list[Vector]
    colours: list[tuple[float, ...]]
    sizes: list[float]
    extents: list[Vector]
    levels: list[int]
    used_image: bool
    source_uvs: list[tuple[float, float]] = field(default_factory=list)

    @property
    def count(self) -> int:
        return len(self.centres)

    def __iter__(self):
        yield self.centres
        yield self.colours
        yield self.count
        yield self.used_image


@dataclass(frozen=True)
class _ColourAnalysis:
    colour: tuple[float, ...]
    texture_error: float
    geometry_angle: float
    source_uv: tuple[float, float] = (0.0, 0.0)


@dataclass
class _VoxelCell:
    centre: Vector
    size: float
    extent: Vector
    level: int
    colour: tuple[float, ...]
    texture_error: float
    geometry_angle: float
    source_uv: tuple[float, float] = (0.0, 0.0)

    def error_score(self, texture_threshold: float, geometry_angle: float) -> float:
        texture_score = self.texture_error / max(texture_threshold, 1.0e-9)
        geometry_score = self.geometry_angle / max(geometry_angle, 1.0e-9)
        return max(texture_score, geometry_score)


def _setting_int(settings, name: str, default: int, minimum: int) -> int:
    try:
        return max(minimum, int(getattr(settings, name, default)))
    except (AttributeError, TypeError, ValueError):
        return max(minimum, int(default))


def sample_budget(settings) -> int:
    return _setting_int(settings, "sample_budget", MAX_GRID_SAMPLES, 1_000)


def voxel_budget(settings) -> int:
    return _setting_int(settings, "voxel_budget", MAX_VOXELS, 1_000)


def sampling_chunk_size(settings) -> int:
    return _setting_int(settings, "sampling_chunk_size", DEFAULT_CHUNK_SIZE, 128)


def cache_budget_bytes(settings) -> int:
    megabytes = _setting_int(
        settings,
        "cache_memory_mb",
        DEFAULT_CACHE_MEMORY_MB,
        16,
    )
    return megabytes * 1024 * 1024


def clear_sampling_cache() -> None:
    global _SAMPLE_CACHE_BYTES
    _SAMPLE_CACHE.clear()
    _SAMPLE_CACHE_BYTES = 0


def sampling_cache_stats() -> dict[str, int]:
    return {
        "entries": len(_SAMPLE_CACHE),
        "bytes": int(_SAMPLE_CACHE_BYTES),
    }


def _cache_get(key: str):
    entry = _SAMPLE_CACHE.get(key)
    if entry is not None:
        _SAMPLE_CACHE.move_to_end(key)
    return entry


def _cache_put(
    key: str,
    centres: Iterable[Iterable[float]],
    colours: Iterable[Iterable[float]],
    sizes: Iterable[float],
    extents: Iterable[Iterable[float]],
    levels: Iterable[int],
    source_uvs: Iterable[Iterable[float]],
    used_image: bool,
    diagnostics: dict[str, object],
    settings,
) -> None:
    global _SAMPLE_CACHE_BYTES
    centre_values = tuple(
        tuple(float(component) for component in centre)
        for centre in centres
    )
    colour_values = tuple(
        tuple(float(component) for component in colour)
        for colour in colours
    )
    size_values = tuple(float(value) for value in sizes)
    extent_values = tuple(
        tuple(float(component) for component in extent)
        for extent in extents
    )
    level_values = tuple(int(value) for value in levels)
    source_uv_values = tuple(
        tuple(float(component) for component in value)
        for value in source_uvs
    )
    if not (
        len(centre_values)
        == len(colour_values)
        == len(size_values)
        == len(extent_values)
        == len(level_values)
        == len(source_uv_values)
    ):
        raise VoxelizerError("Cached voxel arrays have inconsistent lengths.")
    estimated_bytes = len(centre_values) * 120
    budget = cache_budget_bytes(settings)
    if estimated_bytes > budget:
        return
    previous = _SAMPLE_CACHE.pop(key, None)
    if previous is not None:
        _SAMPLE_CACHE_BYTES -= int(previous["estimated_bytes"])
    while _SAMPLE_CACHE and _SAMPLE_CACHE_BYTES + estimated_bytes > budget:
        _old_key, old = _SAMPLE_CACHE.popitem(last=False)
        _SAMPLE_CACHE_BYTES -= int(old["estimated_bytes"])
    _SAMPLE_CACHE[key] = {
        "centres": centre_values,
        "colours": colour_values,
        "sizes": size_values,
        "extents": extent_values,
        "levels": level_values,
        "source_uvs": source_uv_values,
        "used_image": bool(used_image),
        "diagnostics": json.loads(json.dumps(diagnostics)),
        "estimated_bytes": estimated_bytes,
    }
    _SAMPLE_CACHE_BYTES += estimated_bytes


def _canonical_cycle(indices: Iterable[int]) -> tuple[int, ...]:
    """Canonicalize a face boundary independent of start and winding."""

    values = tuple(int(index) for index in indices)
    if not values:
        return values
    reverse = tuple(reversed(values))
    candidates = [
        values[offset:] + values[:offset]
        for offset in range(len(values))
    ]
    candidates.extend(
        reverse[offset:] + reverse[:offset]
        for offset in range(len(reverse))
    )
    return min(candidates)


def _symmetry_bounds(
    mesh: bpy.types.Mesh,
) -> tuple[Vector, Vector, float, float]:
    if not mesh.vertices:
        origin = Vector((0.0, 0.0, 0.0))
        return origin.copy(), origin.copy(), 0.0, SYMMETRY_ABSOLUTE_FLOOR
    bounds_min = Vector(
        tuple(
            min(float(vertex.co[axis]) for vertex in mesh.vertices)
            for axis in range(3)
        )
    )
    bounds_max = Vector(
        tuple(
            max(float(vertex.co[axis]) for vertex in mesh.vertices)
            for axis in range(3)
        )
    )
    diagonal = float((bounds_max - bounds_min).length)
    tolerance = max(
        diagonal * SYMMETRY_RELATIVE_TOLERANCE,
        SYMMETRY_ABSOLUTE_FLOOR,
    )
    return bounds_min, bounds_max, diagonal, tolerance


def _spatial_key(coordinate: Iterable[float], tolerance: float) -> tuple[int, int, int]:
    return tuple(
        int(math.floor(float(value) / tolerance))
        for value in coordinate
    )


def _reflection_vertex_map(
    mesh: bpy.types.Mesh,
    axis: int,
    plane: float,
    tolerance: float,
) -> tuple[Optional[tuple[int, ...]], str, dict[str, object]]:
    buckets: dict[tuple[int, int, int], list[int]] = {}
    coordinates = [vertex.co.copy() for vertex in mesh.vertices]
    for index, coordinate in enumerate(coordinates):
        buckets.setdefault(_spatial_key(coordinate, tolerance), []).append(index)

    neighbours: list[set[int]] = [set() for _vertex in mesh.vertices]
    edge_face_counts: Counter[tuple[int, int]] = Counter()
    incident_face_sizes: list[list[int]] = [[] for _vertex in mesh.vertices]
    for edge in mesh.edges:
        first, second = (int(value) for value in edge.vertices)
        neighbours[first].add(second)
        neighbours[second].add(first)
    for polygon in mesh.polygons:
        polygon_indices = tuple(int(index) for index in polygon.vertices)
        for index in polygon_indices:
            incident_face_sizes[index].append(len(polygon_indices))
        for offset, first in enumerate(polygon_indices):
            second = polygon_indices[(offset + 1) % len(polygon_indices)]
            edge_face_counts[tuple(sorted((first, second)))] += 1

    def local_signature(index: int) -> tuple[object, ...]:
        edge_incidence = sorted(
            edge_face_counts[tuple(sorted((index, neighbour)))]
            for neighbour in neighbours[index]
        )
        return (
            len(neighbours[index]),
            tuple(sorted(incident_face_sizes[index])),
            tuple(edge_incidence),
        )

    def reflected_neighbour_coordinates(index: int) -> list[Vector]:
        result = []
        for neighbour in neighbours[index]:
            reflected = coordinates[neighbour].copy()
            reflected[axis] = 2.0 * plane - reflected[axis]
            result.append(reflected)
        return result

    def neighbours_match(source_index: int, candidate_index: int) -> bool:
        reflected_neighbours = reflected_neighbour_coordinates(source_index)
        candidate_neighbours = sorted(neighbours[candidate_index])
        matched_target_to_source: dict[int, int] = {}

        def assign_neighbour(source_offset: int, visited: set[int]) -> bool:
            target_coordinate = reflected_neighbours[source_offset]
            for target_offset, target_index in enumerate(candidate_neighbours):
                if target_offset in visited:
                    continue
                if (
                    float(
                        (
                            coordinates[target_index]
                            - target_coordinate
                        ).length
                    )
                    > tolerance
                ):
                    continue
                visited.add(target_offset)
                previous_source = matched_target_to_source.get(target_offset)
                if (
                    previous_source is None
                    or assign_neighbour(previous_source, visited)
                ):
                    matched_target_to_source[target_offset] = source_offset
                    return True
            return False

        return all(
            assign_neighbour(source_offset, set())
            for source_offset in range(len(reflected_neighbours))
        )

    def diagnostic_neighbour_signature(
        index: int,
        *,
        reflect: bool,
    ) -> tuple[tuple[float, float, float], ...]:
        values = (
            reflected_neighbour_coordinates(index)
            if reflect
            else [coordinates[neighbour] for neighbour in neighbours[index]]
        )
        return tuple(
            sorted(
                tuple(round(float(value[component]), 7) for component in range(3))
                for value in values
            )
        )

    candidate_lists: list[tuple[int, ...]] = []
    statistics: dict[str, object] = {
        "raw_ambiguous_vertices": 0,
        "topology_ambiguous_vertices": 0,
        "max_raw_candidates": 0,
        "max_topology_candidates": 0,
        "bipartite_pairs": 0,
    }
    for index, coordinate in enumerate(coordinates):
        reflected = coordinate.copy()
        reflected[axis] = 2.0 * plane - reflected[axis]
        bucket_key = _spatial_key(reflected, tolerance)
        raw_candidates = []
        for offset in product((-1, 0, 1), repeat=3):
            neighbour_key = tuple(
                bucket_key[component] + offset[component]
                for component in range(3)
            )
            for candidate in buckets.get(neighbour_key, ()):
                distance = float((coordinates[candidate] - reflected).length)
                if distance <= tolerance:
                    raw_candidates.append((distance, candidate))
        if not raw_candidates:
            return (
                None,
                f"vertex {index} has no reflected correspondence",
                statistics,
            )
        raw_candidates.sort()
        source_signature = local_signature(index)
        topology_candidates = [
            candidate
            for _distance, candidate in raw_candidates
            if (
                local_signature(candidate) == source_signature
                and neighbours_match(index, candidate)
            )
        ]
        statistics["max_raw_candidates"] = max(
            int(statistics["max_raw_candidates"]),
            len(raw_candidates),
        )
        statistics["max_topology_candidates"] = max(
            int(statistics["max_topology_candidates"]),
            len(topology_candidates),
        )
        if len(raw_candidates) > 1:
            statistics["raw_ambiguous_vertices"] = (
                int(statistics["raw_ambiguous_vertices"]) + 1
            )
        if len(topology_candidates) > 1:
            statistics["topology_ambiguous_vertices"] = (
                int(statistics["topology_ambiguous_vertices"]) + 1
            )
        if index == 14 and len(raw_candidates) > 1:
            statistics["vertex_14"] = {
                "source_signature": repr(source_signature),
                "reflected_neighbours": repr(
                    diagnostic_neighbour_signature(index, reflect=True)
                ),
                "raw_candidates": [
                    candidate
                    for _distance, candidate in raw_candidates
                ],
                "topology_candidates": topology_candidates,
                "candidate_signatures": {
                    str(candidate): {
                        "local": repr(local_signature(candidate)),
                        "neighbours": repr(
                            diagnostic_neighbour_signature(
                                candidate,
                                reflect=False,
                            )
                        ),
                        "compatible": neighbours_match(index, candidate),
                    }
                    for _distance, candidate in raw_candidates
                },
            }
        if not topology_candidates:
            return (
                None,
                f"vertex {index} has no topology-compatible reflection",
                statistics,
            )
        candidate_lists.append(tuple(sorted(topology_candidates)))

    mapping = [-1] * len(coordinates)
    negative_vertices = [
        index
        for index, coordinate in enumerate(coordinates)
        if float(coordinate[axis]) < plane - tolerance
    ]
    positive_vertices = {
        index
        for index, coordinate in enumerate(coordinates)
        if float(coordinate[axis]) > plane + tolerance
    }
    plane_vertices = [
        index
        for index in range(len(coordinates))
        if index not in positive_vertices and index not in negative_vertices
    ]
    for index in plane_vertices:
        if index not in candidate_lists[index]:
            return (
                None,
                f"on-plane vertex {index} is not self-compatible under reflection",
                statistics,
            )
        mapping[index] = index

    target_to_source: dict[int, int] = {}

    def assign(source_index: int, visited: set[int]) -> bool:
        for target_index in candidate_lists[source_index]:
            if (
                target_index not in positive_vertices
                or source_index not in candidate_lists[target_index]
                or target_index in visited
            ):
                continue
            visited.add(target_index)
            previous_source = target_to_source.get(target_index)
            if previous_source is None or assign(previous_source, visited):
                target_to_source[target_index] = source_index
                return True
        return False

    for source_index in sorted(negative_vertices):
        if not assign(source_index, set()):
            return (
                None,
                f"vertex {source_index} has no one-to-one topology-compatible reflection",
                statistics,
            )
    for target_index, source_index in target_to_source.items():
        mapping[source_index] = target_index
        mapping[target_index] = source_index
    statistics["bipartite_pairs"] = len(target_to_source)

    if -1 in mapping or len(set(mapping)) != len(mapping):
        return (
            None,
            "reflected vertex correspondence is not one-to-one",
            statistics,
        )
    for index, reflected_index in enumerate(mapping):
        if mapping[reflected_index] != index:
            return (
                None,
                "reflected vertex correspondence is not involutive",
                statistics,
            )
    return tuple(mapping), "vertex correspondence proved", statistics


def _reflection_topology_matches(
    mesh: bpy.types.Mesh,
    mapping: tuple[int, ...],
) -> tuple[bool, str]:
    edge_counter = Counter(
        tuple(sorted((int(edge.vertices[0]), int(edge.vertices[1]))))
        for edge in mesh.edges
    )
    reflected_edges = Counter(
        tuple(sorted((mapping[int(edge.vertices[0])], mapping[int(edge.vertices[1])])))
        for edge in mesh.edges
    )
    if reflected_edges != edge_counter:
        return False, "reflected edge connectivity differs"

    face_counter = Counter(
        _canonical_cycle(polygon.vertices)
        for polygon in mesh.polygons
    )
    reflected_faces = Counter(
        _canonical_cycle(mapping[int(index)] for index in polygon.vertices)
        for polygon in mesh.polygons
    )
    if reflected_faces != face_counter:
        return False, "reflected polygon boundary connectivity differs"
    return True, "vertex, edge, and polygon connectivity proved"


def reflection_symmetry_diagnostics(mesh: bpy.types.Mesh) -> dict[str, object]:
    """Conservatively prove local-space reflection symmetry for X, Y, and Z."""

    bounds_min, bounds_max, diagonal, tolerance = _symmetry_bounds(mesh)
    diagnostics: dict[str, object] = {
        "schema": SYMMETRY_SCHEMA_VERSION,
        "coordinate_space": "OBJECT_LOCAL",
        "scale_diagonal": diagonal,
        "tolerance": tolerance,
        "vertex_count": len(mesh.vertices),
        "edge_count": len(mesh.edges),
        "polygon_count": len(mesh.polygons),
        "axes": {},
        "proven_axes": [],
    }
    axes = diagnostics["axes"]
    proven_axes = diagnostics["proven_axes"]
    assert isinstance(axes, dict)
    assert isinstance(proven_axes, list)
    for axis, axis_name in enumerate(_AXIS_NAMES):
        plane = (float(bounds_min[axis]) + float(bounds_max[axis])) * 0.5
        axis_result: dict[str, object] = {
            "axis": axis_name,
            "plane": plane,
            "tolerance": tolerance,
            "proven": False,
            "vertex_pairs": 0,
            "self_vertices": 0,
            "reason": "",
        }
        mapping, reason, match_statistics = _reflection_vertex_map(
            mesh,
            axis,
            plane,
            tolerance,
        )
        axis_result["matching"] = match_statistics
        if mapping is None:
            axis_result["reason"] = reason
        else:
            topology_matches, topology_reason = _reflection_topology_matches(
                mesh,
                mapping,
            )
            axis_result["reason"] = topology_reason
            if topology_matches:
                axis_result["proven"] = True
                axis_result["vertex_pairs"] = sum(
                    mapping[index] != index
                    for index in range(len(mapping))
                ) // 2
                axis_result["self_vertices"] = sum(
                    mapping[index] == index
                    for index in range(len(mapping))
                )
                proven_axes.append(axis_name)
        axes[axis_name] = axis_result
    return diagnostics


def _symmetry_json(diagnostics: dict[str, object]) -> str:
    return json.dumps(
        diagnostics,
        sort_keys=True,
        separators=(",", ":"),
    )


def _symmetry_cache_fingerprint(diagnostics: dict[str, object]) -> bytes:
    digest = hashlib.sha256()
    digest.update(_symmetry_json(diagnostics).encode("utf-8"))
    return digest.digest()


def _required_axes_preserved(
    source_diagnostics: dict[str, object],
    candidate_diagnostics: dict[str, object],
) -> tuple[bool, list[str]]:
    source_axes = source_diagnostics["axes"]
    candidate_axes = candidate_diagnostics["axes"]
    assert isinstance(source_axes, dict)
    assert isinstance(candidate_axes, dict)
    missing = []
    for axis_name in source_diagnostics["proven_axes"]:
        source_axis = source_axes[axis_name]
        candidate_axis = candidate_axes[axis_name]
        assert isinstance(source_axis, dict)
        assert isinstance(candidate_axis, dict)
        plane_tolerance = max(
            float(source_axis["tolerance"]),
            float(candidate_axis["tolerance"]),
        )
        if (
            not bool(candidate_axis["proven"])
            or abs(float(source_axis["plane"]) - float(candidate_axis["plane"]))
            > plane_tolerance
        ):
            missing.append(str(axis_name))
    return not missing, missing


def sampling_diagnostics(source: bpy.types.Object) -> dict[str, object]:
    """Return a detached copy of the most recent sampling diagnostics."""

    diagnostics = _LAST_SAMPLING_DIAGNOSTICS.get(source.as_pointer(), {})
    return json.loads(json.dumps(diagnostics))


def attach_sampling_diagnostics(
    output: bpy.types.Object,
    source: bpy.types.Object,
) -> None:
    diagnostics = _LAST_SAMPLING_DIAGNOSTICS.get(source.as_pointer())
    if diagnostics:
        output[SAMPLING_DIAGNOSTICS_TAG] = _symmetry_json(diagnostics)


def is_tool_output(obj: object, kind: Optional[str] = None) -> bool:
    if not isinstance(obj, bpy.types.Object):
        return False
    if obj.get(TOOL_TAG) != TOOL_ID:
        return False
    return kind is None or obj.get(KIND_TAG) == kind


def _safe_source_token(name: str) -> str:
    token = re.sub(r"[^A-Za-z0-9_.-]+", "_", name).strip("._")
    return (token or "Mesh")[:38]


def preview_name(source: bpy.types.Object) -> str:
    return f".BTVM_PREVIEW_{_safe_source_token(source.name)}"


def watertight_name(source: bpy.types.Object) -> str:
    return f".BTVM_WATERTIGHT_{_safe_source_token(source.name)}"


def bake_name(source: bpy.types.Object) -> str:
    return f"{source.name}_VOX"


def assert_name_available(
    name: str,
    *,
    replace_owned_preview_for: Optional[bpy.types.Object] = None,
) -> Optional[bpy.types.Object]:
    existing = bpy.data.objects.get(name)
    if existing is None:
        return None
    if (
        replace_owned_preview_for is not None
        and is_tool_output(existing, PREVIEW_KIND)
        and existing.get(SOURCE_TAG) == replace_owned_preview_for.name
    ):
        return existing
    raise VoxelizerError(
        f'Object name "{name}" already exists; refusing to overwrite it. '
        "Rename/delete that object, or use Clear for a tool output."
    )


def mesh_diagnostics(mesh: bpy.types.Mesh) -> dict[str, int | bool]:
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        boundary_edges = sum(len(edge.link_faces) == 1 for edge in bm.edges)
        overfull_edges = sum(len(edge.link_faces) > 2 for edge in bm.edges)
        wire_edges = sum(len(edge.link_faces) == 0 for edge in bm.edges)
        nonmanifold_edges = sum(not edge.is_manifold for edge in bm.edges)
        degenerate_faces = sum(face.calc_area() <= 1.0e-12 for face in bm.faces)
        unseen = set(bm.verts)
        components = 0
        while unseen:
            components += 1
            stack = [unseen.pop()]
            while stack:
                vertex = stack.pop()
                for edge in vertex.link_edges:
                    neighbour = edge.other_vert(vertex)
                    if neighbour in unseen:
                        unseen.remove(neighbour)
                        stack.append(neighbour)
        empty = len(bm.verts) < 4 or len(bm.faces) < 4
        return {
            "vertices": len(bm.verts),
            "edges": len(bm.edges),
            "faces": len(bm.faces),
            "boundary_edges": boundary_edges,
            "overfull_edges": overfull_edges,
            "wire_edges": wire_edges,
            "nonmanifold_edges": nonmanifold_edges,
            "degenerate_faces": degenerate_faces,
            "components": components,
            "empty": empty,
        }
    finally:
        bm.free()


def _diagnostics_ready(diagnostics: dict[str, int | bool]) -> bool:
    return (
        not diagnostics["empty"]
        and diagnostics["boundary_edges"] == 0
        and diagnostics["overfull_edges"] == 0
        and diagnostics["wire_edges"] == 0
        and diagnostics["nonmanifold_edges"] == 0
        and diagnostics["degenerate_faces"] == 0
        and diagnostics["components"] == 1
    )


def is_closed_manifold(mesh: bpy.types.Mesh) -> bool:
    return _diagnostics_ready(mesh_diagnostics(mesh))


def source_signature(mesh: bpy.types.Mesh, repair_voxel_size: float) -> str:
    digest = hashlib.sha256()
    digest.update(struct.pack("<dIII", float(repair_voxel_size), len(mesh.vertices), len(mesh.edges), len(mesh.polygons)))
    for vertex in mesh.vertices:
        digest.update(struct.pack("<3d", float(vertex.co.x), float(vertex.co.y), float(vertex.co.z)))
    for edge in mesh.edges:
        digest.update(struct.pack("<2I", int(edge.vertices[0]), int(edge.vertices[1])))
    for polygon in mesh.polygons:
        indices = tuple(int(index) for index in polygon.vertices)
        digest.update(struct.pack("<I", len(indices)))
        if indices:
            digest.update(struct.pack(f"<{len(indices)}I", *indices))
    return digest.hexdigest()


def _watertight_source_signature(
    mesh: bpy.types.Mesh,
    repair_voxel_size: float,
    symmetry: dict[str, object],
) -> str:
    digest = hashlib.sha256()
    digest.update(source_signature(mesh, repair_voxel_size).encode("ascii"))
    digest.update(_symmetry_cache_fingerprint(symmetry))
    return digest.hexdigest()


@contextmanager
def evaluated_local_mesh(
    context: bpy.types.Context,
    source: bpy.types.Object,
    *,
    preserve_all_data_layers: bool = True,
) -> Iterator[bpy.types.Mesh]:
    """Lease an evaluated object-local mesh and always clear its owner."""

    depsgraph = context.evaluated_depsgraph_get()
    evaluated = source.evaluated_get(depsgraph)
    mesh = evaluated.to_mesh(
        preserve_all_data_layers=preserve_all_data_layers,
        depsgraph=depsgraph,
    )
    if mesh is None:
        raise VoxelizerError(
            f'Could not obtain evaluated mesh geometry for "{source.name}".'
        )
    try:
        yield mesh
    finally:
        evaluated.to_mesh_clear()


def evaluated_geometry_signature(
    context: bpy.types.Context,
    source: bpy.types.Object,
) -> str:
    """Hash evaluated object-local geometry without including object transforms."""

    with evaluated_local_mesh(
        context,
        source,
        preserve_all_data_layers=False,
    ) as mesh:
        return source_signature(mesh, 0.0)


def _image_fingerprint(image: Optional[bpy.types.Image]) -> bytes:
    """Return a bounded fingerprint that notices metadata and sampled pixel edits."""

    if image is None:
        return b"NO_IMAGE"
    digest = hashlib.sha256()
    digest.update(str(getattr(image, "name_full", image.name)).encode("utf-8"))
    digest.update(str(getattr(image, "filepath_raw", "")).encode("utf-8"))
    digest.update(str(getattr(image, "source", "")).encode("ascii", "ignore"))
    digest.update(str(getattr(image.colorspace_settings, "name", "")).encode("utf-8"))
    digest.update(b"\x01" if bool(getattr(image, "is_dirty", False)) else b"\x00")
    try:
        width, height = (int(value) for value in image.size)
        digest.update(struct.pack("<II", width, height))
        pixels = image.pixels
        pixel_count = len(pixels)
        digest.update(struct.pack("<Q", pixel_count))
        if pixel_count:
            stride = max(1, pixel_count // 512)
            for index in range(0, pixel_count, stride):
                digest.update(struct.pack("<f", float(pixels[index])))
    except (AttributeError, RuntimeError, TypeError, ValueError):
        digest.update(b"UNREADABLE")
    return digest.digest()


def _colour_inputs_fingerprint(mesh: bpy.types.Mesh, settings) -> bytes:
    digest = hashlib.sha256()
    uv_name = str(getattr(settings, "uv_map", ""))
    digest.update(uv_name.encode("utf-8"))
    uv_layers = (
        [mesh.uv_layers.get(uv_name)]
        if uv_name and mesh.uv_layers.get(uv_name) is not None
        else list(mesh.uv_layers)
    )
    for uv_layer in uv_layers:
        if uv_layer is None:
            continue
        digest.update(str(uv_layer.name).encode("utf-8"))
        digest.update(struct.pack("<I", len(uv_layer.data)))
        for datum in uv_layer.data:
            digest.update(struct.pack("<2f", float(datum.uv.x), float(datum.uv.y)))
    fallback = tuple(float(value) for value in getattr(
        settings,
        "fallback_color",
        (0.18, 0.48, 0.8, 1.0),
    ))
    digest.update(struct.pack("<4f", *fallback))
    manual_image = getattr(settings, "base_color_image", None)
    digest.update(_image_fingerprint(manual_image))
    auto_material_images = bool(getattr(settings, "auto_material_images", True))
    digest.update(b"\x01" if auto_material_images else b"\x00")
    if manual_image is None and auto_material_images:
        for material in mesh.materials:
            if material is None:
                digest.update(b"NO_MATERIAL")
                continue
            digest.update(str(material.name_full).encode("utf-8"))
            digest.update(struct.pack(
                "<4f",
                *(float(value) for value in material.diffuse_color),
            ))
            image_node = _material_image_node(material)
            digest.update(_image_fingerprint(
                getattr(image_node, "image", None) if image_node is not None else None
            ))
            if image_node is not None:
                digest.update(str(getattr(image_node, "extension", "REPEAT")).encode("ascii"))
                digest.update(_image_node_uv_name(image_node).encode("utf-8"))
    return digest.digest()


def preview_sampling_key(
    context: bpy.types.Context,
    source: bpy.types.Object,
    settings,
) -> str:
    """Key occupancy and colour inputs; display gap is intentionally absent."""

    digest = hashlib.sha256()
    with evaluated_local_mesh(context, source) as mesh:
        digest.update(source_signature(mesh, 0.0).encode("ascii"))
        digest.update(_colour_inputs_fingerprint(mesh, settings))
    digest.update(struct.pack("<d", float(settings.voxel_size)))
    digest.update(b"\x01" if settings.auto_watertight_copy else b"\x00")
    digest.update(struct.pack("<d", float(settings.repair_voxel_size)))
    grid_mode = str(getattr(settings, "grid_origin_mode", "BOUNDS"))
    digest.update(grid_mode.encode("ascii", "ignore"))
    grid_origin = tuple(float(value) for value in getattr(
        settings,
        "grid_origin",
        (0.0, 0.0, 0.0),
    ))
    digest.update(struct.pack("<3d", *grid_origin))
    digest.update(
        b"\x01" if bool(getattr(settings, "use_sparse_candidates", True)) else b"\x00"
    )
    digest.update(struct.pack(
        "<I",
        _setting_int(settings, "sparse_grid_threshold", 50_000, 0),
    ))
    sampling_mode = str(getattr(settings, "sampling_mode", "UNIFORM"))
    digest.update(sampling_mode.encode("ascii", "ignore"))
    digest.update(struct.pack("<I", ADAPTIVE_SCHEMA_VERSION))
    digest.update(struct.pack(
        "<I",
        _setting_int(settings, "adaptive_max_level", 0, 0),
    ))
    digest.update(struct.pack(
        "<I",
        _setting_int(settings, "adaptive_geometry_max_level", 1, 0),
    ))
    digest.update(struct.pack(
        "<2d",
        float(getattr(settings, "adaptive_texture_threshold", 0.16)),
        float(getattr(settings, "adaptive_geometry_angle", 35.0)),
    ))
    digest.update(str(getattr(settings, "texture_filter", "BILINEAR")).encode("ascii"))
    digest.update(struct.pack(
        "<3Q",
        sample_budget(settings),
        voxel_budget(settings),
        _setting_int(
            settings,
            "candidate_expansion_budget",
            sample_budget(settings) * 32,
            sample_budget(settings),
        ),
    ))
    return digest.hexdigest()


def _diagnostic_message(prefix: str, diagnostics: dict[str, int | bool]) -> str:
    return (
        f"{prefix}: {diagnostics['boundary_edges']} boundary edge(s), "
        f"{diagnostics['overfull_edges']} edge(s) with more than two faces, "
        f"{diagnostics['wire_edges']} wire edge(s), "
        f"{diagnostics['nonmanifold_edges']} total non-manifold edge(s), "
        f"{diagnostics['degenerate_faces']} degenerate face(s), "
        f"{diagnostics['components']} component(s), "
        f"{diagnostics['vertices']} vertices, {diagnostics['faces']} faces."
    )


def _hide_helper(helper: bpy.types.Object) -> None:
    helper.hide_render = True
    helper.hide_select = True
    helper.hide_viewport = True
    try:
        helper.hide_set(True)
    except RuntimeError:
        pass


def _remesh_working_object(
    context: bpy.types.Context,
    working: bpy.types.Object,
    voxel_size: float,
) -> None:
    if context.mode != "OBJECT":
        raise VoxelizerError("Automatic watertight repair requires Object Mode.")
    previous_active = context.view_layer.objects.active
    previous_selected = tuple(context.selected_objects)
    try:
        for selected in previous_selected:
            selected.select_set(False)
        working.hide_viewport = False
        working.hide_select = False
        working.hide_set(False)
        working.select_set(True)
        context.view_layer.objects.active = working
        mesh = working.data
        mesh.remesh_voxel_size = float(voxel_size)
        mesh.remesh_voxel_adaptivity = 0.0
        if hasattr(mesh, "use_remesh_fix_poles"):
            mesh.use_remesh_fix_poles = True
        if hasattr(mesh, "use_remesh_preserve_volume"):
            mesh.use_remesh_preserve_volume = True
        if hasattr(mesh, "use_remesh_preserve_attributes"):
            mesh.use_remesh_preserve_attributes = False
        result = bpy.ops.object.voxel_remesh()
        if result != {"FINISHED"}:
            raise VoxelizerError(f"Blender Voxel Remesh returned {result}.")
    finally:
        if working.name in bpy.data.objects:
            working.select_set(False)
        for selected in previous_selected:
            if selected.name in bpy.data.objects:
                try:
                    selected.select_set(True)
                except RuntimeError:
                    pass
        if previous_active is not None and previous_active.name in bpy.data.objects:
            context.view_layer.objects.active = previous_active


def _shift_mesh_for_symmetry(
    mesh: bpy.types.Mesh,
    source_symmetry: dict[str, object],
    factor: float,
) -> None:
    axes = source_symmetry["axes"]
    assert isinstance(axes, dict)
    offsets = Vector((0.0, 0.0, 0.0))
    for axis, axis_name in enumerate(_AXIS_NAMES):
        axis_diagnostics = axes[axis_name]
        assert isinstance(axis_diagnostics, dict)
        if axis_diagnostics["proven"]:
            offsets[axis] = float(axis_diagnostics["plane"]) * factor
    if offsets.length_squared == 0.0:
        return
    for vertex in mesh.vertices:
        vertex.co += offsets
    mesh.update()


def _mirror_missing_helper_axes(
    context: bpy.types.Context,
    working: bpy.types.Object,
    source_symmetry: dict[str, object],
    missing_axes: Iterable[str],
) -> None:
    """Bisect and mirror only axes already proved on the untouched source."""

    missing = set(missing_axes)
    if not missing:
        return
    previous_active = context.view_layer.objects.active
    previous_selected = tuple(context.selected_objects)
    try:
        for selected in previous_selected:
            selected.select_set(False)
        working.hide_viewport = False
        working.hide_select = False
        working.hide_set(False)
        working.select_set(True)
        context.view_layer.objects.active = working

        modifier = working.modifiers.new(".BTVM Symmetry Preservation", "MIRROR")
        for axis, axis_name in enumerate(_AXIS_NAMES):
            modifier.use_axis[axis] = axis_name in missing
            modifier.use_bisect_axis[axis] = axis_name in missing
            modifier.use_bisect_flip_axis[axis] = False
        modifier.use_clip = True
        modifier.use_mirror_merge = True
        modifier.merge_threshold = max(
            float(source_symmetry["tolerance"]),
            SYMMETRY_ABSOLUTE_FLOOR,
        )
        result = bpy.ops.object.modifier_apply(modifier=modifier.name)
        if result != {"FINISHED"}:
            raise VoxelizerError(
                f"Symmetry-preservation Mirror returned {result}."
            )
    finally:
        if working.name in bpy.data.objects:
            working.select_set(False)
        for selected in previous_selected:
            if selected.name in bpy.data.objects:
                try:
                    selected.select_set(True)
                except RuntimeError:
                    pass
        if previous_active is not None and previous_active.name in bpy.data.objects:
            context.view_layer.objects.active = previous_active


def _evaluated_mesh_diagnostics_and_symmetry(
    context: bpy.types.Context,
    source: bpy.types.Object,
) -> tuple[dict[str, int | bool], dict[str, object]]:
    context.view_layer.update()
    with evaluated_local_mesh(context, source) as mesh:
        return mesh_diagnostics(mesh), reflection_symmetry_diagnostics(mesh)


def ensure_sampling_object(
    context: bpy.types.Context,
    source: bpy.types.Object,
    settings,
    *,
    source_mesh: bpy.types.Mesh,
    source_diagnostics: dict[str, int | bool],
    source_symmetry: dict[str, object],
) -> tuple[bpy.types.Object, bool]:
    if _diagnostics_ready(source_diagnostics):
        return source, False
    if not settings.auto_watertight_copy:
        raise VoxelizerError(
            _diagnostic_message(
                "Source is not a single closed manifold and Auto Watertight Copy is off",
                source_diagnostics,
            )
        )

    repair_size = float(settings.repair_voxel_size)
    if repair_size <= 0.0:
        raise VoxelizerError("Repair Voxel Size must be greater than zero.")
    signature = _watertight_source_signature(
        source_mesh,
        repair_size,
        source_symmetry,
    )
    name = watertight_name(source)
    existing = bpy.data.objects.get(name)
    if existing is not None and not (
        is_tool_output(existing, HELPER_KIND)
        and existing.get(SOURCE_TAG) == source.name
    ):
        raise VoxelizerError(
            f'Object name "{name}" already exists; refusing to overwrite '
            "an unowned watertight helper."
        )
    if existing is not None:
        existing_diagnostics, existing_symmetry = (
            _evaluated_mesh_diagnostics_and_symmetry(context, existing)
        )
        symmetry_preserved, _missing_axes = _required_axes_preserved(
            source_symmetry,
            existing_symmetry,
        )
        if (
            existing.get(SOURCE_SIGNATURE_TAG) == signature
            and _diagnostics_ready(existing_diagnostics)
            and symmetry_preserved
        ):
            existing.matrix_world = source.matrix_world.copy()
            existing[SOURCE_SYMMETRY_TAG] = _symmetry_json(source_symmetry)
            existing[HELPER_SYMMETRY_TAG] = _symmetry_json(existing_symmetry)
            _hide_helper(existing)
            return existing, False

    working_mesh = source_mesh.copy()
    working_mesh.name = f"{name}_BuildMesh"
    working = bpy.data.objects.new(f"{name}_BUILD", working_mesh)
    collection = source.users_collection[0] if source.users_collection else context.collection
    collection.objects.link(working)
    working.matrix_world = source.matrix_world.copy()
    tag_output(working, source, HELPER_KIND)
    working.hide_render = True
    try:
        _shift_mesh_for_symmetry(working.data, source_symmetry, -1.0)
        _remesh_working_object(context, working, repair_size)
        _shift_mesh_for_symmetry(working.data, source_symmetry, 1.0)
        repaired_diagnostics, repaired_symmetry = (
            _evaluated_mesh_diagnostics_and_symmetry(context, working)
        )
        symmetry_preserved, missing_axes = _required_axes_preserved(
            source_symmetry,
            repaired_symmetry,
        )
        if not symmetry_preserved:
            _shift_mesh_for_symmetry(working.data, source_symmetry, -1.0)
            try:
                _mirror_missing_helper_axes(
                    context,
                    working,
                    source_symmetry,
                    missing_axes,
                )
            finally:
                _shift_mesh_for_symmetry(working.data, source_symmetry, 1.0)
            repaired_diagnostics, repaired_symmetry = (
                _evaluated_mesh_diagnostics_and_symmetry(context, working)
            )
            symmetry_preserved, missing_axes = _required_axes_preserved(
                source_symmetry,
                repaired_symmetry,
            )
        if not symmetry_preserved:
            raise VoxelizerError(
                "Automatic watertight repair could not preserve proved local "
                f"reflection symmetry on axis/axes: {', '.join(missing_axes)}."
            )
        if not _diagnostics_ready(repaired_diagnostics):
            raise VoxelizerError(
                _diagnostic_message(
                    "Automatic watertight repair did not produce one closed manifold",
                    repaired_diagnostics,
                )
            )
        working.data.materials.clear()
        working[SOURCE_SIGNATURE_TAG] = signature
        working[REPAIR_SIZE_TAG] = repair_size
        working[SOURCE_SYMMETRY_TAG] = _symmetry_json(source_symmetry)
        working[HELPER_SYMMETRY_TAG] = _symmetry_json(repaired_symmetry)
        if existing is None:
            working.name = name
            helper = working
        else:
            old_mesh = existing.data
            existing.data = working.data
            bpy.data.objects.remove(working, do_unlink=True)
            if old_mesh.users == 0:
                bpy.data.meshes.remove(old_mesh)
            helper = existing
            tag_output(helper, source, HELPER_KIND)
            helper[SOURCE_SIGNATURE_TAG] = signature
            helper[REPAIR_SIZE_TAG] = repair_size
            helper[SOURCE_SYMMETRY_TAG] = _symmetry_json(source_symmetry)
            helper[HELPER_SYMMETRY_TAG] = _symmetry_json(repaired_symmetry)
        helper.matrix_world = source.matrix_world.copy()
        _hide_helper(helper)
        return helper, True
    except Exception:
        if working.name in bpy.data.objects:
            failed_mesh = working.data
            bpy.data.objects.remove(working, do_unlink=True)
            if failed_mesh.users == 0:
                bpy.data.meshes.remove(failed_mesh)
        raise


def selected_source(context: bpy.types.Context) -> bpy.types.Object:
    if context.mode != "OBJECT":
        raise VoxelizerError("Voxelizer requires Object Mode.")
    source = context.active_object
    if source is None or source.type != "MESH" or source not in context.selected_objects:
        raise VoxelizerError("Select one active Mesh object.")
    if is_tool_output(source):
        raise VoxelizerError("Select the original source Mesh, not a Voxelizer output.")
    return source


def source_objects(context: bpy.types.Context, settings) -> list[bpy.types.Object]:
    """Resolve active, selected, or collection sources in deterministic order."""

    if context.mode != "OBJECT":
        raise VoxelizerError("Chromoxel requires Object Mode.")
    scope = str(getattr(settings, "source_scope", "ACTIVE"))
    if scope == "ACTIVE":
        return [selected_source(context)]
    if scope == "SELECTED":
        candidates = tuple(context.selected_objects)
    elif scope == "COLLECTION":
        collection = getattr(settings, "source_collection", None)
        if collection is None:
            raise VoxelizerError("Choose a Source Collection.")
        candidates = tuple(collection.all_objects)
    else:
        raise VoxelizerError(f'Unknown Source Scope "{scope}".')
    include_hidden = bool(getattr(settings, "include_hidden", False))
    sources = []
    for candidate in candidates:
        if candidate.type != "MESH" or is_tool_output(candidate):
            continue
        if not include_hidden and (
            candidate.hide_viewport
            or candidate.hide_get()
        ):
            continue
        sources.append(candidate)
    sources.sort(key=lambda item: item.name_full.casefold())
    if not sources:
        raise VoxelizerError(
            "The selected scope contains no eligible Mesh objects."
        )
    return sources


def estimate_sources(
    context: bpy.types.Context,
    sources: Iterable[bpy.types.Object],
    settings,
) -> dict[str, object]:
    """Estimate candidate work and transient memory without building voxels."""

    validate_settings(settings)
    items = []
    total_grid = 0
    total_candidates = 0
    total_output_voxels = 0
    total_bytes = 0
    for source in sources:
        with evaluated_local_mesh(context, source) as mesh:
            if not mesh.vertices:
                continue
            bounds_min = Vector(tuple(
                min(float(vertex.co[axis]) for vertex in mesh.vertices)
                for axis in range(3)
            ))
            bounds_max = Vector(tuple(
                max(float(vertex.co[axis]) for vertex in mesh.vertices)
                for axis in range(3)
            ))
            symmetry = reflection_symmetry_diagnostics(mesh)
            indices, coordinates, _report = _build_sampling_lattice(
                bounds_min,
                bounds_max,
                float(settings.voxel_size),
                symmetry,
                settings,
            )
            counts = [len(axis) for axis in coordinates]
            full_grid = counts[0] * counts[1] * counts[2]
            surface_area = sum(float(polygon.area) for polygon in mesh.polygons)
            sparse_estimate = min(
                full_grid,
                max(1, int(math.ceil(
                    surface_area / max(float(settings.voxel_size) ** 2, 1.0e-12)
                    * 8.0
                ))),
            )
            adaptive_levels = (
                _setting_int(settings, "adaptive_max_level", 2, 0)
                if str(getattr(settings, "sampling_mode", "UNIFORM")) == "ADAPTIVE"
                else 0
            )
            estimated_output = min(
                voxel_budget(settings),
                sparse_estimate * (4 ** adaptive_levels),
            )
            estimated_bytes = estimated_output * 128
            item = {
                "name": source.name,
                "axis_counts": counts,
                "full_grid_samples": full_grid,
                "estimated_candidates": sparse_estimate,
                "estimated_output_voxels": estimated_output,
                "estimated_memory_bytes": estimated_bytes,
                "lattice_index_ranges": [
                    (axis.start, axis.stop - 1) for axis in indices
                ],
            }
            items.append(item)
            total_grid += full_grid
            total_candidates += sparse_estimate
            total_output_voxels += estimated_output
            total_bytes += estimated_bytes
    return {
        "sources": items,
        "source_count": len(items),
        "full_grid_samples": total_grid,
        "estimated_candidates": total_candidates,
        "estimated_output_voxels": total_output_voxels,
        "estimated_memory_bytes": total_bytes,
        "within_sample_budget": all(
            int(item["estimated_candidates"]) <= sample_budget(settings)
            for item in items
        ),
        "within_cache_budget": total_bytes <= cache_budget_bytes(settings),
    }


def validate_settings(settings) -> None:
    if settings.voxel_size <= 0.0:
        raise VoxelizerError("Voxel Size must be greater than zero.")
    if settings.cube_gap < 0.0 or settings.cube_gap >= settings.voxel_size:
        raise VoxelizerError("Cube Gap must be non-negative and smaller than Voxel Size.")


def ensure_colour_material() -> bpy.types.Material:
    material = bpy.data.materials.get(MATERIAL_NAME)
    if material is not None and material.get(TOOL_TAG) != TOOL_ID:
        raise VoxelizerError(
            f'Material name "{MATERIAL_NAME}" is occupied by user data; '
            "refusing to overwrite it."
        )
    if material is None:
        material = bpy.data.materials.new(MATERIAL_NAME)
        material[TOOL_TAG] = TOOL_ID
    material.use_nodes = True
    nodes = material.node_tree.nodes
    links = material.node_tree.links
    nodes.clear()
    output = nodes.new("ShaderNodeOutputMaterial")
    shader = nodes.new("ShaderNodeBsdfPrincipled")
    colour = nodes.new("ShaderNodeVertexColor")
    colour.layer_name = COLOUR_ATTRIBUTE
    roughness = nodes.new("ShaderNodeAttribute")
    roughness.attribute_name = "voxel_roughness"
    metallic = nodes.new("ShaderNodeAttribute")
    metallic.attribute_name = "voxel_metallic"
    emission = nodes.new("ShaderNodeAttribute")
    emission.attribute_name = "voxel_emission"
    links.new(colour.outputs["Color"], shader.inputs["Base Color"])
    links.new(colour.outputs["Alpha"], shader.inputs["Alpha"])
    if shader.inputs.get("Roughness") is not None:
        links.new(roughness.outputs["Fac"], shader.inputs["Roughness"])
    if shader.inputs.get("Metallic") is not None:
        links.new(metallic.outputs["Fac"], shader.inputs["Metallic"])
    emission_color = shader.inputs.get("Emission Color")
    if emission_color is None:
        emission_color = shader.inputs.get("Emission")
    if emission_color is not None:
        links.new(colour.outputs["Color"], emission_color)
    if shader.inputs.get("Emission Strength") is not None:
        links.new(emission.outputs["Fac"], shader.inputs["Emission Strength"])
    links.new(shader.outputs["BSDF"], output.inputs["Surface"])
    material.diffuse_color = (0.18, 0.48, 0.8, 1.0)
    return material


def _barycentric_weights(point: Vector, a: Vector, b: Vector, c: Vector):
    v0 = b - a
    v1 = c - a
    v2 = point - a
    d00 = v0.dot(v0)
    d01 = v0.dot(v1)
    d11 = v1.dot(v1)
    d20 = v2.dot(v0)
    d21 = v2.dot(v1)
    denominator = d00 * d11 - d01 * d01
    if abs(denominator) < 1.0e-16:
        return None
    v = (d11 * d20 - d01 * d21) / denominator
    w = (d00 * d21 - d01 * d20) / denominator
    return (1.0 - v - w, v, w)


def _srgb_channel_to_scene_linear(value: float) -> float:
    """Decode one normalized sRGB channel for a scene-linear color attribute."""

    value = max(0.0, min(1.0, float(value)))
    if value <= 0.04045:
        return value / 12.92
    return ((value + 0.055) / 1.055) ** 2.4


def _linked_upstream_node(socket, node_type: str):
    """Find the first upstream node of ``node_type`` from one input socket."""

    stack = [link.from_node for link in getattr(socket, "links", ())]
    visited = set()
    while stack:
        node = stack.pop(0)
        pointer = node.as_pointer()
        if pointer in visited:
            continue
        visited.add(pointer)
        if node.type == node_type:
            return node
        for input_socket in node.inputs:
            stack.extend(link.from_node for link in input_socket.links)
    return None


def _material_principled(material: Optional[bpy.types.Material]):
    if material is None or not material.use_nodes or material.node_tree is None:
        return None
    outputs = [
        node for node in material.node_tree.nodes
        if node.type == "OUTPUT_MATERIAL"
    ]
    output = next(
        (node for node in outputs if bool(getattr(node, "is_active_output", False))),
        outputs[0] if outputs else None,
    )
    if output is not None:
        surface = output.inputs.get("Surface")
        if surface is not None:
            principled = _linked_upstream_node(surface, "BSDF_PRINCIPLED")
            if principled is not None:
                return principled
    return next(
        (node for node in material.node_tree.nodes if node.type == "BSDF_PRINCIPLED"),
        None,
    )


def _material_image_node(material: Optional[bpy.types.Material]):
    principled = _material_principled(material)
    if principled is None:
        return None
    base_colour = principled.inputs.get("Base Color")
    if base_colour is None:
        return None
    node = _linked_upstream_node(base_colour, "TEX_IMAGE")
    if node is None or getattr(node, "image", None) is None:
        return None
    return node


def _material_flat_colour(
    material: Optional[bpy.types.Material],
    fallback: tuple[float, ...],
) -> tuple[float, ...]:
    principled = _material_principled(material)
    if principled is not None:
        base_colour = principled.inputs.get("Base Color")
        if base_colour is not None and not base_colour.is_linked:
            value = tuple(float(component) for component in base_colour.default_value)
            if len(value) >= 4:
                return value[:4]
    if material is not None:
        value = tuple(float(component) for component in material.diffuse_color)
        if len(value) >= 4:
            return value[:4]
    return fallback


def _active_uv_layer(mesh: bpy.types.Mesh):
    if not mesh.uv_layers:
        return None
    active = getattr(mesh.uv_layers, "active", None)
    if active is not None:
        return active
    return mesh.uv_layers[0]


def _image_node_uv_name(image_node) -> str:
    if image_node is None:
        return ""
    vector = image_node.inputs.get("Vector")
    uv_node = _linked_upstream_node(vector, "UVMAP") if vector is not None else None
    return str(getattr(uv_node, "uv_map", "")) if uv_node is not None else ""


class _ImageBuffer:
    """Immutable image snapshot with repeat/clamp-aware nearest and bilinear reads."""

    def __init__(self, image: bpy.types.Image, extension: str = "REPEAT"):
        self.image = image
        self.extension = extension if extension in {"REPEAT", "EXTEND", "CLIP"} else "REPEAT"
        self.width = 0
        self.height = 0
        self.pixels: tuple[float, ...] = ()
        try:
            self.width, self.height = (int(value) for value in image.size)
            if self.width > 0 and self.height > 0:
                self.pixels = tuple(float(value) for value in image.pixels[:])
        except (AttributeError, RuntimeError, TypeError, ValueError):
            self.width = self.height = 0
            self.pixels = ()

    @property
    def valid(self) -> bool:
        return bool(self.pixels and self.width > 0 and self.height > 0)

    def _index(self, value: int, extent: int) -> Optional[int]:
        if self.extension == "REPEAT":
            return value % extent
        if self.extension == "CLIP" and (value < 0 or value >= extent):
            return None
        return min(extent - 1, max(0, value))

    def _pixel(self, x: int, y: int) -> Optional[tuple[float, ...]]:
        x_index = self._index(x, self.width)
        y_index = self._index(y, self.height)
        if x_index is None or y_index is None:
            return None
        offset = (y_index * self.width + x_index) * 4
        if offset + 3 >= len(self.pixels):
            return None
        raw = self.pixels[offset:offset + 4]
        return (
            _srgb_channel_to_scene_linear(raw[0]),
            _srgb_channel_to_scene_linear(raw[1]),
            _srgb_channel_to_scene_linear(raw[2]),
            raw[3],
        )

    def nearest(self, uv: Vector) -> Optional[tuple[float, ...]]:
        return self._pixel(
            int(math.floor(float(uv.x) * self.width)),
            int(math.floor(float(uv.y) * self.height)),
        )

    def bilinear(self, uv: Vector) -> Optional[tuple[float, ...]]:
        x = float(uv.x) * self.width - 0.5
        y = float(uv.y) * self.height - 0.5
        x0 = math.floor(x)
        y0 = math.floor(y)
        tx = x - x0
        ty = y - y0
        samples = (
            self._pixel(x0, y0),
            self._pixel(x0 + 1, y0),
            self._pixel(x0, y0 + 1),
            self._pixel(x0 + 1, y0 + 1),
        )
        if any(sample is None for sample in samples):
            return None
        first, second, third, fourth = samples
        assert first is not None and second is not None
        assert third is not None and fourth is not None
        return tuple(
            (
                first[channel] * (1.0 - tx) * (1.0 - ty)
                + second[channel] * tx * (1.0 - ty)
                + third[channel] * (1.0 - tx) * ty
                + fourth[channel] * tx * ty
            )
            for channel in range(4)
        )


class ColourSampler:
    """Material-aware UV sampler with filtered footprint error estimation."""

    def __init__(
        self,
        mesh: bpy.types.Mesh,
        uv_name: str,
        image: Optional[bpy.types.Image],
        fallback: Iterable[float],
        *,
        auto_material_images: bool = True,
        filter_mode: str = "BILINEAR",
    ):
        self.mesh = mesh
        self.fallback = tuple(float(component) for component in fallback)
        self.filter_mode = filter_mode if filter_mode in {"NEAREST", "BILINEAR"} else "BILINEAR"
        self.source_bvh = None
        self.triangles_by_polygon: dict[int, list[object]] = {}
        self.material_entries: dict[
            int,
            tuple[Optional[_ImageBuffer], Optional[object], tuple[float, ...]],
        ] = {}
        self._buffers: dict[tuple[int, str], _ImageBuffer] = {}

        requested_uv = mesh.uv_layers.get(uv_name) if uv_name else None
        default_uv = requested_uv or _active_uv_layer(mesh)
        materials = list(mesh.materials)
        slot_count = max(1, len(materials))
        for material_index in range(slot_count):
            material = materials[material_index] if material_index < len(materials) else None
            flat_colour = _material_flat_colour(material, self.fallback)
            image_node = None
            selected_image = image
            if selected_image is None and auto_material_images:
                image_node = _material_image_node(material)
                selected_image = getattr(image_node, "image", None)
            uv_layer = requested_uv
            if uv_layer is None and image_node is not None:
                node_uv_name = _image_node_uv_name(image_node)
                uv_layer = mesh.uv_layers.get(node_uv_name) if node_uv_name else None
            uv_layer = uv_layer or default_uv
            buffer = None
            if selected_image is not None and uv_layer is not None:
                extension = str(getattr(image_node, "extension", "REPEAT"))
                buffer_key = (selected_image.as_pointer(), extension)
                buffer = self._buffers.get(buffer_key)
                if buffer is None:
                    buffer = _ImageBuffer(selected_image, extension)
                    self._buffers[buffer_key] = buffer
                if not buffer.valid:
                    buffer = None
            self.material_entries[material_index] = (buffer, uv_layer, flat_colour)

        if any(entry[0] is not None for entry in self.material_entries.values()):
            source_vertices = [vertex.co.copy() for vertex in mesh.vertices]
            source_polygons = [tuple(polygon.vertices) for polygon in mesh.polygons]
            self.source_bvh = BVHTree.FromPolygons(
                source_vertices,
                source_polygons,
                all_triangles=False,
            )
        else:
            # Geometry-detail analysis still needs the original surface BVH.
            source_vertices = [vertex.co.copy() for vertex in mesh.vertices]
            source_polygons = [tuple(polygon.vertices) for polygon in mesh.polygons]
            self.source_bvh = BVHTree.FromPolygons(
                source_vertices,
                source_polygons,
                all_triangles=False,
            )

        mesh.calc_loop_triangles()
        for triangle in mesh.loop_triangles:
            self.triangles_by_polygon.setdefault(triangle.polygon_index, []).append(triangle)
        self.edge_features = self._build_edge_features()

    @property
    def uses_image(self) -> bool:
        return any(entry[0] is not None for entry in self.material_entries.values())

    def _entry(self, polygon_index: int):
        if 0 <= polygon_index < len(self.mesh.polygons):
            material_index = int(self.mesh.polygons[polygon_index].material_index)
        else:
            material_index = 0
        return self.material_entries.get(
            material_index,
            self.material_entries.get(0, (None, None, self.fallback)),
        )

    def _triangle_sample_data(self, point: Vector, polygon_index: int):
        best = None
        best_penalty = math.inf
        for triangle in self.triangles_by_polygon.get(polygon_index, ()):
            a, b, c = (self.mesh.vertices[index].co for index in triangle.vertices)
            weights = _barycentric_weights(point, a, b, c)
            if weights is None:
                continue
            penalty = sum(
                max(0.0, -weight) + max(0.0, weight - 1.0)
                for weight in weights
            )
            if penalty < best_penalty:
                best = (triangle, weights)
                best_penalty = penalty
            if penalty <= 1.0e-5:
                break
        if best is None:
            return None
        triangle, weights = best
        buffer, uv_layer, flat_colour = self._entry(polygon_index)
        if buffer is None or uv_layer is None:
            return triangle, weights, None, None, flat_colour
        uv_data = uv_layer.data
        uvs = [uv_data[loop_index].uv.copy() for loop_index in triangle.loops]
        uv = uvs[0] * weights[0] + uvs[1] * weights[1] + uvs[2] * weights[2]
        return triangle, weights, buffer, (uv, uvs), flat_colour

    def _read(self, buffer: _ImageBuffer, uv: Vector):
        if self.filter_mode == "NEAREST":
            return buffer.nearest(uv)
        return buffer.bilinear(uv)

    def sample(self, point: Vector, polygon_index: int):
        data = self._triangle_sample_data(point, polygon_index)
        if data is None:
            return self.fallback
        _triangle, _weights, buffer, uv_data, flat_colour = data
        if buffer is None or uv_data is None:
            return flat_colour
        uv, _uvs = uv_data
        return self._read(buffer, uv) or flat_colour

    def _footprint_samples(
        self,
        point: Vector,
        polygon_index: int,
        cell_size: float,
    ) -> tuple[list[tuple[float, ...]], tuple[float, ...], tuple[float, float]]:
        data = self._triangle_sample_data(point, polygon_index)
        if data is None:
            return [self.fallback], self.fallback, (0.0, 0.0)
        triangle, _weights, buffer, uv_data, flat_colour = data
        if buffer is None or uv_data is None:
            return [flat_colour], flat_colour, (0.0, 0.0)
        uv, uvs = uv_data
        if cell_size <= 0.0:
            centre_colour = self._read(buffer, uv) or flat_colour
            return [centre_colour], centre_colour, (float(uv.x), float(uv.y))
        vertices = [self.mesh.vertices[index].co for index in triangle.vertices]
        u_scale = 0.0
        v_scale = 0.0
        for first, second in ((0, 1), (1, 2), (2, 0)):
            length = float((vertices[second] - vertices[first]).length)
            if length <= 1.0e-12:
                continue
            u_scale = max(u_scale, abs(float(uvs[second].x - uvs[first].x)) / length)
            v_scale = max(v_scale, abs(float(uvs[second].y - uvs[first].y)) / length)
        radius_u = min(0.25, cell_size * 0.45 * u_scale)
        radius_v = min(0.25, cell_size * 0.45 * v_scale)
        samples = []
        for v_offset in (-1.0, 0.0, 1.0):
            for u_offset in (-1.0, 0.0, 1.0):
                sampled = self._read(
                    buffer,
                    Vector((
                        float(uv.x) + u_offset * radius_u,
                        float(uv.y) + v_offset * radius_v,
                    )),
                )
                if sampled is not None:
                    samples.append(sampled)
        centre_colour = self._read(buffer, uv) or flat_colour
        return samples or [centre_colour], centre_colour, (float(uv.x), float(uv.y))

    def _build_edge_features(self):
        edge_polygons: dict[tuple[int, int], list[int]] = {}
        for polygon in self.mesh.polygons:
            indices = tuple(int(index) for index in polygon.vertices)
            for offset, first in enumerate(indices):
                second = indices[(offset + 1) % len(indices)]
                edge_polygons.setdefault(tuple(sorted((first, second))), []).append(polygon.index)
        features: dict[int, list[tuple[Vector, Vector, float]]] = {}
        for (first, second), polygons in edge_polygons.items():
            if len(polygons) != 2:
                angle = 180.0
            else:
                first_normal = self.mesh.polygons[polygons[0]].normal
                second_normal = self.mesh.polygons[polygons[1]].normal
                cosine = max(-1.0, min(1.0, float(first_normal.dot(second_normal))))
                angle = math.degrees(math.acos(cosine))
            if angle <= 1.0e-5:
                continue
            start = self.mesh.vertices[first].co.copy()
            end = self.mesh.vertices[second].co.copy()
            for polygon_index in polygons:
                features.setdefault(polygon_index, []).append((start, end, angle))
        return features

    @staticmethod
    def _point_segment_distance(point: Vector, start: Vector, end: Vector) -> float:
        segment = end - start
        denominator = float(segment.length_squared)
        if denominator <= 1.0e-16:
            return float((point - start).length)
        factor = max(0.0, min(1.0, float((point - start).dot(segment)) / denominator))
        return float((point - (start + segment * factor)).length)

    def _geometry_angle(self, point: Vector, polygon_index: int, cell_size: float) -> float:
        radius = max(1.0e-9, cell_size * math.sqrt(3.0) * 0.65)
        maximum = 0.0
        for start, end, angle in self.edge_features.get(polygon_index, ()):
            if self._point_segment_distance(point, start, end) <= radius:
                maximum = max(maximum, angle)
        return maximum

    def analyse(self, point: Vector, polygon_index: int, cell_size: float) -> _ColourAnalysis:
        samples, centre_colour, source_uv = self._footprint_samples(
            point,
            polygon_index,
            cell_size,
        )
        if len(samples) <= 1:
            texture_error = 0.0
        else:
            texture_error = max(
                max(sample[channel] for sample in samples)
                - min(sample[channel] for sample in samples)
                for channel in range(4)
            )
        return _ColourAnalysis(
            # Footprint samples detect unresolved detail; the displayed colour
            # remains the filtered value at the voxel centre. Averaging the
            # footprint here visibly washed out rings and other thin markings.
            colour=centre_colour,
            texture_error=float(texture_error),
            geometry_angle=self._geometry_angle(point, polygon_index, cell_size),
            source_uv=source_uv,
        )

    def analyse_nearest(self, query_point: Vector, cell_size: float) -> _ColourAnalysis:
        if self.source_bvh is None:
            return _ColourAnalysis(self.fallback, 0.0, 0.0)
        nearest = self.source_bvh.find_nearest(query_point)
        if nearest is None or nearest[0] is None or nearest[2] is None:
            return _ColourAnalysis(self.fallback, 0.0, 0.0)
        location, _normal, polygon_index, _distance = nearest
        return self.analyse(location, polygon_index, cell_size)

    def sample_nearest_original(self, query_point: Vector):
        return self.analyse_nearest(query_point, 0.0).colour


_CUBE_CORNERS = (
    (-1, -1, -1),
    (1, -1, -1),
    (1, 1, -1),
    (-1, 1, -1),
    (-1, -1, 1),
    (1, -1, 1),
    (1, 1, 1),
    (-1, 1, 1),
)
_CUBE_FACES = (
    (0, 3, 2, 1),
    (4, 5, 6, 7),
    (0, 1, 5, 4),
    (1, 2, 6, 5),
    (2, 3, 7, 6),
    (3, 0, 4, 7),
)


def _build_sampling_lattice(
    bounds_min: Vector,
    bounds_max: Vector,
    voxel_size: float,
    source_symmetry: dict[str, object],
    settings,
) -> tuple[list[range], list[list[float]], dict[str, object]]:
    """Build deterministic local-space axes for bounds or fixed-origin grids."""

    shell_distance = voxel_size * math.sqrt(3.0) * 0.52
    source_axes = source_symmetry["axes"]
    assert isinstance(source_axes, dict)
    proven_axes = set(str(axis) for axis in source_symmetry["proven_axes"])
    grid_mode = str(getattr(settings, "grid_origin_mode", "BOUNDS"))
    if grid_mode not in {"BOUNDS", "OBJECT", "CUSTOM"}:
        grid_mode = "BOUNDS"
    custom_origin = tuple(float(value) for value in getattr(
        settings,
        "grid_origin",
        (0.0, 0.0, 0.0),
    ))
    lattice_indices: list[range] = []
    lattice_coordinates: list[list[float]] = []
    lattice_report: dict[str, object] = {}
    for axis, axis_name in enumerate(_AXIS_NAMES):
        if axis_name in proven_axes:
            axis_diagnostics = source_axes[axis_name]
            assert isinstance(axis_diagnostics, dict)
            plane = float(axis_diagnostics["plane"])
            radius = max(
                plane - float(bounds_min[axis]),
                float(bounds_max[axis]) - plane,
            )
            half_steps = max(0, int(math.ceil(radius / voxel_size)))
            indices = range(-half_steps, half_steps + 1)
            if len(indices) > sample_budget(settings):
                raise VoxelizerError(
                    f"The {axis_name} grid axis would require {len(indices):,} "
                    "cells; increase Voxel Size."
                )
            coordinates = [plane + index * voxel_size for index in indices]
            lattice_report[axis_name] = {
                "mode": "PROVEN_PLANE_CENTERED",
                "plane": plane,
                "index_min": -half_steps,
                "index_max": half_steps,
                "count": len(coordinates),
            }
        elif grid_mode == "BOUNDS":
            count = max(
                1,
                int(math.ceil(
                    (float(bounds_max[axis]) - float(bounds_min[axis]))
                    / voxel_size
                )),
            )
            indices = range(count)
            if len(indices) > sample_budget(settings):
                raise VoxelizerError(
                    f"The {axis_name} grid axis would require {len(indices):,} "
                    "cells; increase Voxel Size."
                )
            coordinates = [
                float(bounds_min[axis]) + (index + 0.5) * voxel_size
                for index in indices
            ]
            lattice_report[axis_name] = {
                "mode": "BOUNDS_HALF_CELL",
                "bounds_min": float(bounds_min[axis]),
                "index_min": 0,
                "index_max": count - 1,
                "count": len(coordinates),
            }
        else:
            anchor = 0.0 if grid_mode == "OBJECT" else custom_origin[axis]
            minimum = int(math.ceil(
                (float(bounds_min[axis]) - shell_distance - anchor) / voxel_size
            ))
            maximum = int(math.floor(
                (float(bounds_max[axis]) + shell_distance - anchor) / voxel_size
            ))
            if minimum > maximum:
                middle = int(round(
                    (((float(bounds_min[axis]) + float(bounds_max[axis])) * 0.5) - anchor)
                    / voxel_size
                ))
                minimum = maximum = middle
            indices = range(minimum, maximum + 1)
            if len(indices) > sample_budget(settings):
                raise VoxelizerError(
                    f"The {axis_name} grid axis would require {len(indices):,} "
                    "cells; increase Voxel Size."
                )
            coordinates = [anchor + index * voxel_size for index in indices]
            lattice_report[axis_name] = {
                "mode": f"{grid_mode}_FIXED_ORIGIN",
                "origin": anchor,
                "index_min": minimum,
                "index_max": maximum,
                "count": len(coordinates),
            }
        lattice_indices.append(indices)
        lattice_coordinates.append(coordinates)
    return lattice_indices, lattice_coordinates, lattice_report


def _cell_key(centre: Vector, size: float) -> tuple[float, float, float, float]:
    return (
        round(float(centre.x), 10),
        round(float(centre.y), 10),
        round(float(centre.z), 10),
        round(float(size), 10),
    )


def _symmetry_orbit_centres(
    centre: Vector,
    source_symmetry: dict[str, object],
) -> list[Vector]:
    axes = source_symmetry["axes"]
    assert isinstance(axes, dict)
    proven_axes = set(str(axis) for axis in source_symmetry["proven_axes"])
    variants = []
    for axis, axis_name in enumerate(_AXIS_NAMES):
        value = float(centre[axis])
        if axis_name in proven_axes:
            diagnostics = axes[axis_name]
            assert isinstance(diagnostics, dict)
            mirrored = 2.0 * float(diagnostics["plane"]) - value
            variants.append((value,) if abs(mirrored - value) <= 1.0e-10 else (value, mirrored))
        else:
            variants.append((value,))
    unique: dict[tuple[float, float, float], Vector] = {}
    for coordinate in product(*variants):
        vector = Vector(coordinate)
        key = tuple(round(float(value), 10) for value in vector)
        unique[key] = vector
    return [unique[key] for key in sorted(unique)]


def _canonical_orbit_key(
    centre: Vector,
    size: float,
    source_symmetry: dict[str, object],
) -> tuple[float, float, float, float]:
    return min(
        _cell_key(candidate, size)
        for candidate in _symmetry_orbit_centres(centre, source_symmetry)
    )


def _nearest_surface_overlaps_adaptive_cell(
    centre: Vector,
    extent: Vector,
    nearest_location: Vector,
) -> bool:
    """Reject circumsphere-only hits that cannot survive subdivision.

    The uniform compatibility path deliberately keeps the historic spherical
    surface shell. Adaptive cells additionally require the nearest surface point
    to sit inside a slightly expanded cell AABB. The ten-percent axis margin
    retains edge/corner coverage while preventing a thin textured surface from
    being hidden behind a coarse, non-intersecting outer layer.
    """

    return all(
        abs(float(nearest_location[axis]) - float(centre[axis]))
        <= float(extent[axis]) * (0.5 + ADAPTIVE_CELL_AXIS_MARGIN) + 1.0e-9
        for axis in range(3)
    )


def _planar_refinement_axis(
    cell: _VoxelCell,
    bvh: BVHTree,
) -> Optional[int]:
    """Return the normal axis for surface-preserving grid-aligned refinement."""
    nearest = bvh.find_nearest(cell.centre)
    if nearest is None or nearest[1] is None:
        return None
    normal = nearest[1].normalized()
    axis = max(range(3), key=lambda index: abs(float(normal[index])))
    if abs(float(normal[axis])) < ADAPTIVE_PLANAR_NORMAL_ALIGNMENT:
        return None
    return axis


def _adaptive_refine_cells_iter(
    source: bpy.types.Object,
    settings,
    *,
    bvh: BVHTree,
    sampler: ColourSampler,
    source_symmetry: dict[str, object],
    cells: list[_VoxelCell],
) -> Iterator[SamplingProgress]:
    """Refine high-error surface cells on a deterministic power-of-two lattice."""

    maximum_level = _setting_int(settings, "adaptive_max_level", 2, 0)
    geometry_maximum_level = min(
        maximum_level,
        _setting_int(settings, "adaptive_geometry_max_level", 1, 0),
    )
    texture_threshold = max(
        1.0e-6,
        float(getattr(settings, "adaptive_texture_threshold", 0.16)),
    )
    geometry_angle = max(
        1.0e-3,
        float(getattr(settings, "adaptive_geometry_angle", 35.0)),
    )
    maximum_voxels = voxel_budget(settings)
    refinement_test_limit = sample_budget(settings)
    chunk_size = sampling_chunk_size(settings)
    tests = 0
    refined_parent_count = 0
    planar_refined_parent_count = 0
    budget_limited = False
    level_reports = []
    working = list(cells)

    for level in range(maximum_level):
        groups: dict[tuple[float, float, float, float], list[_VoxelCell]] = {}
        for cell in working:
            if cell.level != level:
                continue
            groups.setdefault(
                _canonical_orbit_key(cell.centre, cell.size, source_symmetry),
                [],
            ).append(cell)
        candidates = []
        for key, group in groups.items():
            score = max(
                max(
                    cell.texture_error / max(texture_threshold, 1.0e-9),
                    (
                        cell.geometry_angle / max(geometry_angle, 1.0e-9)
                        if level < geometry_maximum_level
                        else 0.0
                    ),
                )
                for cell in group
            )
            if score >= 1.0:
                candidates.append((score, key, group))
        candidates.sort(key=lambda item: (-item[0], item[1]))
        output = {_cell_key(cell.centre, cell.size): cell for cell in working}
        refined_this_level = 0
        children_this_level = 0
        for candidate_number, (_score, _key, group) in enumerate(candidates, start=1):
            canonical_parent = min(
                group,
                key=lambda cell: _cell_key(cell.centre, cell.size),
            )
            child_size = canonical_parent.size * 0.5
            child_offset = child_size * 0.5
            planar_axis = _planar_refinement_axis(
                canonical_parent,
                bvh,
            )
            child_signs = (
                tuple(
                    0 if axis == planar_axis else sign[axis]
                    for axis in range(3)
                )
                for sign in _CUBE_CORNERS
            ) if planar_axis is not None else iter(_CUBE_CORNERS)
            child_signs = tuple(dict.fromkeys(child_signs))
            if tests + len(child_signs) > refinement_test_limit:
                budget_limited = True
                break
            generated: dict[tuple[float, float, float, float], _VoxelCell] = {}
            for signs in child_signs:
                tests += 1
                child_centre = canonical_parent.centre + Vector(tuple(
                    sign * child_offset for sign in signs
                ))
                child_extent = Vector((child_size, child_size, child_size))
                if planar_axis is not None:
                    child_extent[planar_axis] = canonical_parent.extent[planar_axis]
                shell_distance = float(child_extent.length) * 0.52
                nearest = bvh.find_nearest(child_centre, shell_distance)
                if (
                    nearest is None
                    or nearest[0] is None
                    or nearest[3] is None
                    or float(nearest[3]) > shell_distance
                    or not _nearest_surface_overlaps_adaptive_cell(
                        child_centre,
                        child_extent,
                        nearest[0],
                    )
                ):
                    continue
                for orbit_centre in _symmetry_orbit_centres(
                    child_centre,
                    source_symmetry,
                ):
                    analysis = sampler.analyse_nearest(orbit_centre, child_size)
                    child = _VoxelCell(
                        centre=orbit_centre,
                        size=child_size,
                        extent=child_extent.copy(),
                        level=level + 1,
                        colour=analysis.colour,
                        texture_error=analysis.texture_error,
                        geometry_angle=analysis.geometry_angle,
                        source_uv=analysis.source_uv,
                    )
                    generated[_cell_key(child.centre, child.size)] = child
            if not generated:
                continue
            parent_keys = {_cell_key(cell.centre, cell.size) for cell in group}
            projected_count = len(output) - len(parent_keys) + sum(
                key not in output for key in generated
            )
            if projected_count > maximum_voxels:
                budget_limited = True
                continue
            for parent_key in parent_keys:
                output.pop(parent_key, None)
            output.update(generated)
            refined_this_level += len(group)
            refined_parent_count += len(group)
            if planar_axis is not None:
                planar_refined_parent_count += len(group)
            children_this_level += len(generated)
            if candidate_number % chunk_size == 0:
                yield SamplingProgress(
                    "ADAPTIVE",
                    candidate_number,
                    max(1, len(candidates)),
                    f"Refining level {level + 1} detail for {source.name}",
                )
        working = sorted(
            output.values(),
            key=lambda cell: (
                cell.level,
                float(cell.centre.z),
                float(cell.centre.y),
                float(cell.centre.x),
            ),
        )
        level_reports.append({
            "level": level + 1,
            "candidate_groups": len(candidates),
            "refined_parents": refined_this_level,
            "generated_children": children_this_level,
            "voxel_count": len(working),
        })
        yield SamplingProgress(
            "ADAPTIVE",
            len(candidates),
            max(1, len(candidates)),
            f"Completed adaptive level {level + 1} for {source.name}",
        )
        if refined_this_level == 0 or budget_limited:
            break

    histogram = Counter(cell.level for cell in working)
    return working, {
        "schema": ADAPTIVE_SCHEMA_VERSION,
        "enabled": maximum_level > 0,
        "max_level": maximum_level,
        "texture_threshold": texture_threshold,
        "geometry_angle_degrees": geometry_angle,
        "geometry_max_level": geometry_maximum_level,
        "refinement_tests": tests,
        "refinement_test_limit": refinement_test_limit,
        "refined_parent_count": refined_parent_count,
        "planar_refined_parent_count": planar_refined_parent_count,
        "budget_limited": budget_limited,
        "level_histogram": {str(level): count for level, count in sorted(histogram.items())},
        "levels": level_reports,
    }


def _sample_surface_voxels_from_meshes_iter(
    context: bpy.types.Context,
    source: bpy.types.Object,
    settings,
    *,
    source_mesh: bpy.types.Mesh,
    source_symmetry: dict[str, object],
    sampling_object: bpy.types.Object,
    helper_rebuilt: bool,
    sampling_mesh: bpy.types.Mesh,
) -> Iterator[SamplingProgress]:
    """Incrementally sample while evaluated mesh leases remain live."""

    sampling_symmetry = reflection_symmetry_diagnostics(sampling_mesh)
    symmetry_preserved, missing_axes = _required_axes_preserved(
        source_symmetry,
        sampling_symmetry,
    )
    if not symmetry_preserved:
        raise VoxelizerError(
            "Sampling geometry does not preserve proved source reflection "
            f"symmetry on axis/axes: {', '.join(missing_axes)}."
        )
    sampling_vertices = [vertex.co.copy() for vertex in sampling_mesh.vertices]
    sampling_polygons = [tuple(polygon.vertices) for polygon in sampling_mesh.polygons]
    bvh = BVHTree.FromPolygons(
        sampling_vertices,
        sampling_polygons,
        all_triangles=False,
    )
    if bvh is None:
        raise VoxelizerError("Could not build a surface acceleration structure.")

    bounds_min = Vector(
        tuple(
            min(vertex.co[axis] for vertex in sampling_mesh.vertices)
            for axis in range(3)
        )
    )
    bounds_max = Vector(
        tuple(
            max(vertex.co[axis] for vertex in sampling_mesh.vertices)
            for axis in range(3)
        )
    )
    voxel_size = float(settings.voxel_size)
    proven_axes = set(str(axis) for axis in source_symmetry["proven_axes"])
    lattice_indices, lattice_coordinates, lattice_report = _build_sampling_lattice(
        bounds_min,
        bounds_max,
        voxel_size,
        source_symmetry,
        settings,
    )
    counts = [len(coordinates) for coordinates in lattice_coordinates]
    full_grid_count = counts[0] * counts[1] * counts[2]
    canonical_offset_floors = [
        max(0, min(counts[axis], -lattice_indices[axis].start))
        if _AXIS_NAMES[axis] in proven_axes
        else 0
        for axis in range(3)
    ]
    canonical_counts = [
        counts[axis] - canonical_offset_floors[axis]
        for axis in range(3)
    ]
    canonical_grid_count = (
        canonical_counts[0] * canonical_counts[1] * canonical_counts[2]
    )
    work_limit = sample_budget(settings)
    if max(counts) > work_limit:
        raise VoxelizerError(
            f"One grid axis would require {max(counts):,} cells; increase "
            f"Voxel Size (limit {work_limit:,})."
        )

    shell_distance = voxel_size * math.sqrt(3.0) * 0.52
    chunk_size = sampling_chunk_size(settings)
    sparse_requested = bool(getattr(settings, "use_sparse_candidates", True))
    sparse_threshold = _setting_int(
        settings,
        "sparse_grid_threshold",
        50_000,
        0,
    )
    use_sparse_candidates = (
        sparse_requested and canonical_grid_count >= sparse_threshold
    )
    candidate_expansion_budget = _setting_int(
        settings,
        "candidate_expansion_budget",
        work_limit * 32,
        work_limit,
    )
    candidate_expansion_tests = 0
    if use_sparse_candidates:
        sampling_mesh.calc_loop_triangles()
        triangles = tuple(sampling_mesh.loop_triangles)
        candidate_set: set[tuple[int, int, int]] = set()
        next_yield = chunk_size
        for triangle_offset, triangle in enumerate(triangles):
            triangle_coordinates = [
                sampling_mesh.vertices[index].co
                for index in triangle.vertices
            ]
            lower = []
            upper = []
            for axis in range(3):
                minimum = min(float(point[axis]) for point in triangle_coordinates)
                maximum = max(float(point[axis]) for point in triangle_coordinates)
                coordinates = lattice_coordinates[axis]
                lower.append(bisect_left(coordinates, minimum - shell_distance))
                upper.append(bisect_right(coordinates, maximum + shell_distance))
            for axis in range(3):
                lower[axis] = max(lower[axis], canonical_offset_floors[axis])
            expansion_count = (
                (upper[0] - lower[0])
                * (upper[1] - lower[1])
                * (upper[2] - lower[2])
            )
            candidate_expansion_tests += expansion_count
            if candidate_expansion_tests > candidate_expansion_budget:
                raise VoxelizerError(
                    "Triangle candidate expansion exceeded the configured "
                    f"budget ({candidate_expansion_budget:,}); increase "
                    "Voxel Size or Candidate Expansion Budget."
                )
            # itertools.product plus set.update performs the hot insertion loop
            # in C while preserving the exact expanded-triangle candidate set.
            candidate_set.update(product(
                range(lower[0], upper[0]),
                range(lower[1], upper[1]),
                range(lower[2], upper[2]),
            ))
            if len(candidate_set) > work_limit:
                raise VoxelizerError(
                    f"Sparse surface candidates exceeded {work_limit:,}; "
                    "increase Voxel Size or the Sample Budget."
                )
            if candidate_expansion_tests >= next_yield:
                yield SamplingProgress(
                    "CANDIDATES",
                    triangle_offset + 1,
                    max(1, len(triangles)),
                    f"Building sparse candidates for {source.name}",
                )
                next_yield = (
                    (candidate_expansion_tests // chunk_size) + 1
                ) * chunk_size
        candidate_offsets = sorted(
            candidate_set,
            key=lambda key: (key[2], key[1], key[0]),
        )
    else:
        if canonical_grid_count > work_limit:
            raise VoxelizerError(
                f"Grid would require {canonical_grid_count:,} canonical samples; increase "
                f"Voxel Size (limit {work_limit:,})."
            )
        candidate_offsets = [
            (x_offset, y_offset, z_offset)
            for z_offset in range(canonical_offset_floors[2], counts[2])
            for y_offset in range(canonical_offset_floors[1], counts[1])
            for x_offset in range(canonical_offset_floors[0], counts[0])
        ]
        candidate_expansion_tests = len(candidate_offsets)
    candidate_count = len(candidate_offsets)
    if not candidate_offsets:
        raise VoxelizerError("No sampling candidates were produced.")
    yield SamplingProgress(
        "CANDIDATES",
        candidate_count,
        candidate_count,
        f"Prepared {candidate_count:,} candidates for {source.name}",
    )

    sampler = ColourSampler(
        source_mesh,
        settings.uv_map,
        settings.base_color_image,
        settings.fallback_color,
        auto_material_images=bool(getattr(settings, "auto_material_images", True)),
        filter_mode=str(getattr(settings, "texture_filter", "BILINEAR")),
    )
    adaptive_enabled = (
        str(getattr(settings, "sampling_mode", "UNIFORM")) == "ADAPTIVE"
        and _setting_int(settings, "adaptive_max_level", 2, 0) > 0
    )
    analysis_cell_size = voxel_size if adaptive_enabled else 0.0
    centres: list[Vector] = []
    colours: list[tuple[float, ...]] = []
    analyses: list[_ColourAnalysis] = []
    occupied_seed_count = 0
    orbit_added_count = 0
    adaptive_rejected_seed_count = 0
    maximum_voxels = voxel_budget(settings)
    if not proven_axes:
        for candidate_number, (x_offset, y_offset, z_offset) in enumerate(
            candidate_offsets,
            start=1,
        ):
            centre = Vector((
                lattice_coordinates[0][x_offset],
                lattice_coordinates[1][y_offset],
                lattice_coordinates[2][z_offset],
            ))
            nearest = bvh.find_nearest(centre, shell_distance)
            if nearest is not None and nearest[0] is not None and nearest[3] is not None:
                location, _normal, _polygon_index, distance = nearest
                if distance <= shell_distance:
                    if adaptive_enabled and not _nearest_surface_overlaps_adaptive_cell(
                        centre,
                        Vector((voxel_size, voxel_size, voxel_size)),
                        location,
                    ):
                        adaptive_rejected_seed_count += 1
                    else:
                        analysis = sampler.analyse_nearest(location, analysis_cell_size)
                        centres.append(centre)
                        colours.append(analysis.colour)
                        analyses.append(analysis)
                        occupied_seed_count += 1
                        if len(centres) > maximum_voxels:
                            raise VoxelizerError(
                                f"Surface exceeded {maximum_voxels:,} voxels; "
                                "increase Voxel Size or the Voxel Budget."
                            )
            if candidate_number % chunk_size == 0:
                yield SamplingProgress(
                    "OCCUPANCY",
                    candidate_number,
                    candidate_count,
                    f"Sampling {source.name}",
                )
    else:
        selected_indices: set[tuple[int, int, int]] = set()
        for candidate_number, (x_offset, y_offset, z_offset) in enumerate(
            candidate_offsets,
            start=1,
        ):
            centre = Vector((
                lattice_coordinates[0][x_offset],
                lattice_coordinates[1][y_offset],
                lattice_coordinates[2][z_offset],
            ))
            nearest = bvh.find_nearest(centre, shell_distance)
            if nearest is not None and nearest[0] is not None and nearest[3] is not None:
                if nearest[3] <= shell_distance:
                    if adaptive_enabled and not _nearest_surface_overlaps_adaptive_cell(
                        centre,
                        Vector((voxel_size, voxel_size, voxel_size)),
                        nearest[0],
                    ):
                        adaptive_rejected_seed_count += 1
                    else:
                        occupied_seed_count += 1
                        key = (
                            lattice_indices[0][x_offset],
                            lattice_indices[1][y_offset],
                            lattice_indices[2][z_offset],
                        )
                        axis_variants = [
                            (value, -value)
                            if _AXIS_NAMES[axis] in proven_axes and value != 0
                            else (value,)
                            for axis, value in enumerate(key)
                        ]
                        selected_indices.update(product(*axis_variants))
                        if len(selected_indices) > maximum_voxels:
                            raise VoxelizerError(
                                f"Surface exceeded {maximum_voxels:,} voxels; "
                                "increase Voxel Size or the Voxel Budget."
                            )
            if candidate_number % chunk_size == 0:
                yield SamplingProgress(
                    "OCCUPANCY",
                    candidate_number,
                    candidate_count,
                    f"Sampling symmetric occupancy for {source.name}",
                )

        coordinate_lookup = [
            {
                index: lattice_coordinates[axis][offset]
                for offset, index in enumerate(lattice_indices[axis])
            }
            for axis in range(3)
        ]
        ordered_indices = sorted(
            selected_indices,
            key=lambda key: (key[2], key[1], key[0]),
        )
        for colour_number, (x_index, y_index, z_index) in enumerate(
            ordered_indices,
            start=1,
        ):
            centre = Vector(
                (
                    coordinate_lookup[0][x_index],
                    coordinate_lookup[1][y_index],
                    coordinate_lookup[2][z_index],
                )
            )
            nearest = bvh.find_nearest(centre)
            if nearest is None or nearest[0] is None:
                raise VoxelizerError(
                    "Could not independently colour-sample a symmetry orbit centre."
                )
            centres.append(centre)
            analysis = sampler.analyse_nearest(nearest[0], analysis_cell_size)
            colours.append(analysis.colour)
            analyses.append(analysis)
            if colour_number % chunk_size == 0:
                yield SamplingProgress(
                    "COLOUR",
                    colour_number,
                    len(ordered_indices),
                    f"Sampling colours for {source.name}",
                )
        orbit_added_count = max(0, len(centres) - occupied_seed_count)
    if not centres:
        raise VoxelizerError("No surface voxels were produced; decrease Voxel Size.")
    base_count = len(centres)
    cells = [
        _VoxelCell(
            centre=centre,
            size=voxel_size,
            extent=Vector((voxel_size, voxel_size, voxel_size)),
            level=0,
            colour=colour,
            texture_error=analysis.texture_error,
            geometry_angle=analysis.geometry_angle,
            source_uv=analysis.source_uv,
        )
        for centre, colour, analysis in zip(centres, colours, analyses)
    ]
    adaptive_diagnostics = {
        "schema": ADAPTIVE_SCHEMA_VERSION,
        "enabled": False,
        "max_level": 0,
        "level_histogram": {"0": len(cells)},
        "levels": [],
        "budget_limited": False,
    }
    if adaptive_enabled:
        cells, adaptive_diagnostics = yield from _adaptive_refine_cells_iter(
            source,
            settings,
            bvh=bvh,
            sampler=sampler,
            source_symmetry=source_symmetry,
            cells=cells,
        )
    centres = [cell.centre for cell in cells]
    colours = [cell.colour for cell in cells]
    sizes = [cell.size for cell in cells]
    extents = [cell.extent for cell in cells]
    levels = [cell.level for cell in cells]
    source_uvs = [cell.source_uv for cell in cells]
    diagnostics = {
        "schema": SYMMETRY_SCHEMA_VERSION,
        "source_symmetry": source_symmetry,
        "sampling_symmetry": sampling_symmetry,
        "proven_axes": sorted(proven_axes),
        "helper_used": sampling_object is not source,
        "helper_rebuilt": bool(helper_rebuilt),
        "voxel_size": voxel_size,
        "shell_distance": shell_distance,
        "lattice": lattice_report,
        "grid_origin_mode": str(getattr(settings, "grid_origin_mode", "BOUNDS")),
        "candidate_strategy": (
            "TRIANGLE_AABB_SPARSE"
            if use_sparse_candidates
            else "FULL_GRID_DISABLED"
            if not sparse_requested
            else "FULL_GRID_SMALL_VOLUME"
        ),
        "full_grid_count": full_grid_count,
        "canonical_grid_count": canonical_grid_count,
        "candidate_count": candidate_count,
        "candidate_expansion_tests": candidate_expansion_tests,
        "candidate_reduction_ratio": (
            0.0
            if full_grid_count <= 0
            else 1.0 - (candidate_count / full_grid_count)
        ),
        "chunk_size": chunk_size,
        "cache_hit": False,
        "occupied_seed_count": occupied_seed_count,
        "adaptive_rejected_seed_count": adaptive_rejected_seed_count,
        "orbit_added_count": orbit_added_count,
        "base_selected_count": base_count,
        "selected_count": len(centres),
        "adaptive": adaptive_diagnostics,
        "selection": (
            "ADAPTIVE_POWER_OF_TWO_SYMMETRY_CLOSURE"
            if adaptive_enabled and proven_axes
            else "ADAPTIVE_POWER_OF_TWO"
            if adaptive_enabled
            else "PROVEN_AXIS_INTEGER_ORBIT_CLOSURE"
            if proven_axes
            else "LEGACY_NO_CLOSURE"
        ),
    }
    _LAST_SAMPLING_DIAGNOSTICS[source.as_pointer()] = diagnostics
    yield SamplingProgress(
        "FINALIZE",
        len(centres),
        len(centres),
        f"Finalized {len(centres):,} voxels for {source.name}",
    )
    return VoxelSampleResult(
        centres=centres,
        colours=colours,
        sizes=sizes,
        extents=extents,
        levels=levels,
        used_image=sampler.uses_image,
        source_uvs=source_uvs,
    )


def _sampling_cache_key(source: bpy.types.Object, sampling_key: str) -> str:
    return f"{source.as_pointer()}:{sampling_key}"


def sample_surface_voxels_iter(
    context: bpy.types.Context,
    source: bpy.types.Object,
    settings,
    *,
    cache_key: Optional[str] = None,
    use_cache: bool = True,
) -> Iterator[SamplingProgress]:
    """Incrementally sample one source and return the result on completion.

    Consumers advance this generator between UI events.  The final voxel tuple is
    carried by ``StopIteration.value`` so the same implementation serves modal
    operators and the synchronous/background API.
    """

    validate_settings(settings)
    sampling_key = cache_key or preview_sampling_key(context, source, settings)
    cache_id = _sampling_cache_key(source, sampling_key)
    if use_cache:
        entry = _cache_get(cache_id)
        if entry is not None:
            diagnostics = json.loads(json.dumps(entry["diagnostics"]))
            diagnostics["cache_hit"] = True
            diagnostics["cache_entries"] = len(_SAMPLE_CACHE)
            diagnostics["cache_bytes"] = int(_SAMPLE_CACHE_BYTES)
            _LAST_SAMPLING_DIAGNOSTICS[source.as_pointer()] = diagnostics
            centres = [Vector(value) for value in entry["centres"]]
            colours = [tuple(value) for value in entry["colours"]]
            sizes = [float(value) for value in entry.get(
                "sizes",
                [float(settings.voxel_size)] * len(centres),
            )]
            extents = [Vector(value) for value in entry.get(
                "extents",
                [(size, size, size) for size in sizes],
            )]
            levels = [int(value) for value in entry.get(
                "levels",
                [0] * len(centres),
            )]
            source_uvs = [tuple(value) for value in entry.get(
                "source_uvs",
                [(0.0, 0.0)] * len(centres),
            )]
            yield SamplingProgress(
                "CACHE",
                1,
                1,
                f"Reused {len(centres):,} cached voxels for {source.name}",
            )
            return VoxelSampleResult(
                centres=centres,
                colours=colours,
                sizes=sizes,
                extents=extents,
                levels=levels,
                used_image=bool(entry["used_image"]),
                source_uvs=source_uvs,
            )

    with evaluated_local_mesh(context, source) as source_mesh:
        source_diagnostics = mesh_diagnostics(source_mesh)
        source_symmetry = reflection_symmetry_diagnostics(source_mesh)
        sampling_object, helper_rebuilt = ensure_sampling_object(
            context,
            source,
            settings,
            source_mesh=source_mesh,
            source_diagnostics=source_diagnostics,
            source_symmetry=source_symmetry,
        )
        if sampling_object is source:
            result = yield from _sample_surface_voxels_from_meshes_iter(
                context,
                source,
                settings,
                source_mesh=source_mesh,
                source_symmetry=source_symmetry,
                sampling_object=sampling_object,
                helper_rebuilt=helper_rebuilt,
                sampling_mesh=source_mesh,
            )
        else:
            with evaluated_local_mesh(context, sampling_object) as sampling_mesh:
                result = yield from _sample_surface_voxels_from_meshes_iter(
                    context,
                    source,
                    settings,
                    source_mesh=source_mesh,
                    source_symmetry=source_symmetry,
                    sampling_object=sampling_object,
                    helper_rebuilt=helper_rebuilt,
                    sampling_mesh=sampling_mesh,
                )

    if not isinstance(result, VoxelSampleResult):
        centres, colours, _count, used_image = result
        result = VoxelSampleResult(
            centres=centres,
            colours=colours,
            sizes=[float(settings.voxel_size)] * len(centres),
            extents=[Vector((float(settings.voxel_size),) * 3)] * len(centres),
            levels=[0] * len(centres),
            used_image=used_image,
            source_uvs=[(0.0, 0.0)] * len(centres),
        )
    diagnostics = dict(_LAST_SAMPLING_DIAGNOSTICS[source.as_pointer()])
    diagnostics["cache_hit"] = False
    _cache_put(
        cache_id,
        result.centres,
        result.colours,
        result.sizes,
        result.extents,
        result.levels,
        result.source_uvs or [(0.0, 0.0)] * result.count,
        result.used_image,
        diagnostics,
        settings,
    )
    diagnostics["cache_entries"] = len(_SAMPLE_CACHE)
    diagnostics["cache_bytes"] = int(_SAMPLE_CACHE_BYTES)
    _LAST_SAMPLING_DIAGNOSTICS[source.as_pointer()] = diagnostics
    return result


def _consume_progress_generator(generator, progress_callback=None):
    while True:
        try:
            progress = next(generator)
        except StopIteration as stop:
            return stop.value
        if progress_callback is not None:
            progress_callback(progress)


def sample_surface_voxels(
    context: bpy.types.Context,
    source: bpy.types.Object,
    settings,
    *,
    cache_key: Optional[str] = None,
    use_cache: bool = True,
    progress_callback=None,
) -> VoxelSampleResult:
    """Synchronous sampling API used by scripts and background tests."""

    return _consume_progress_generator(
        sample_surface_voxels_iter(
            context,
            source,
            settings,
            cache_key=cache_key,
            use_cache=use_cache,
        ),
        progress_callback,
    )


def build_voxel_mesh_iter(
    context: bpy.types.Context,
    source: bpy.types.Object,
    settings,
    mesh_name: str,
    *,
    cache_key: Optional[str] = None,
) -> Iterator[SamplingProgress]:
    """Incrementally build the realized cube mesh used by Bake."""

    sample_result = yield from sample_surface_voxels_iter(
        context, source, settings, cache_key=cache_key
    )
    if not isinstance(sample_result, VoxelSampleResult):
        centres, colours, _count, used_image = sample_result
        sample_result = VoxelSampleResult(
            centres=centres,
            colours=colours,
            sizes=[float(settings.voxel_size)] * len(centres),
            extents=[Vector((float(settings.voxel_size),) * 3)] * len(centres),
            levels=[0] * len(centres),
            used_image=used_image,
            source_uvs=[(0.0, 0.0)] * len(centres),
        )
    centres = sample_result.centres
    colours = sample_result.colours
    sizes = sample_result.sizes
    extents = sample_result.extents
    levels = sample_result.levels
    source_uvs = sample_result.source_uvs or [(0.0, 0.0)] * sample_result.count
    count = sample_result.count
    used_image = sample_result.used_image
    base_voxel_size = float(settings.voxel_size)
    fill_ratio = max(
        1.0e-6,
        min(1.0, 1.0 - float(settings.cube_gap) / base_voxel_size),
    )
    result_vertices = []
    result_faces = []
    chunk_size = sampling_chunk_size(settings)
    for voxel_number, (centre, cell_extent) in enumerate(
        zip(centres, extents),
        start=1,
    ):
        half_extent = Vector(cell_extent) * fill_ratio * 0.5
        first_vertex = len(result_vertices)
        result_vertices.extend(
            (
                centre.x + x_sign * half_extent.x,
                centre.y + y_sign * half_extent.y,
                centre.z + z_sign * half_extent.z,
            )
            for x_sign, y_sign, z_sign in _CUBE_CORNERS
        )
        result_faces.extend(
            tuple(first_vertex + index for index in face)
            for face in _CUBE_FACES
        )
        if voxel_number % chunk_size == 0:
            yield SamplingProgress(
                "BAKE_GEOMETRY",
                voxel_number,
                count,
                f"Building cube geometry for {source.name}",
            )

    result = bpy.data.meshes.new(mesh_name)
    completed = False
    try:
        result.from_pydata(result_vertices, (), result_faces)
        result.update()
        attribute = result.color_attributes.new(
            name=COLOUR_ATTRIBUTE,
            type="FLOAT_COLOR",
            domain="CORNER",
        )
        polygon_count = len(result.polygons)
        size_attribute = result.attributes.new(
            name=SIZE_ATTRIBUTE,
            type="FLOAT",
            domain="FACE",
        )
        extent_attribute = result.attributes.new(
            name=EXTENT_ATTRIBUTE,
            type="FLOAT_VECTOR",
            domain="FACE",
        )
        level_attribute = result.attributes.new(
            name=LEVEL_ATTRIBUTE,
            type="INT",
            domain="FACE",
        )
        source_uv_attribute = result.attributes.new(
            name="source_uv",
            type="FLOAT2",
            domain="FACE",
        )
        for polygon_number, polygon in enumerate(result.polygons, start=1):
            voxel_index = polygon.index // 6
            colour = colours[voxel_index]
            size_attribute.data[polygon.index].value = sizes[voxel_index]
            extent_attribute.data[polygon.index].vector = extents[voxel_index]
            level_attribute.data[polygon.index].value = levels[voxel_index]
            source_uv_attribute.data[polygon.index].vector = source_uvs[voxel_index]
            for loop_index in polygon.loop_indices:
                attribute.data[loop_index].color = colour
            if polygon_number % (chunk_size * 6) == 0:
                yield SamplingProgress(
                    "BAKE_COLOUR",
                    polygon_number,
                    polygon_count,
                    f"Writing voxel colours for {source.name}",
                )
        result.materials.append(ensure_colour_material())
        result.update()
        completed = True
    finally:
        if not completed and result.name in bpy.data.meshes:
            bpy.data.meshes.remove(result)
    return result, count, used_image


def build_voxel_mesh(
    context: bpy.types.Context,
    source: bpy.types.Object,
    settings,
    mesh_name: str,
    *,
    cache_key: Optional[str] = None,
    progress_callback=None,
) -> tuple[bpy.types.Mesh, int, bool]:
    """Synchronous realized-mesh API used by scripts and background tests."""

    return _consume_progress_generator(
        build_voxel_mesh_iter(
            context,
            source,
            settings,
            mesh_name,
            cache_key=cache_key,
        ),
        progress_callback,
    )


def tag_output(
    output: bpy.types.Object,
    source: bpy.types.Object,
    kind: str,
) -> None:
    output[TOOL_TAG] = TOOL_ID
    output[KIND_TAG] = kind
    output[SOURCE_TAG] = source.name
    if kind in {PREVIEW_KIND, BAKE_KIND}:
        attach_sampling_diagnostics(output, source)


def link_output(
    context: bpy.types.Context,
    source: bpy.types.Object,
    mesh: bpy.types.Mesh,
    name: str,
    kind: str,
) -> bpy.types.Object:
    output = bpy.data.objects.new(name, mesh)
    collection = source.users_collection[0] if source.users_collection else context.collection
    collection.objects.link(output)
    output.matrix_world = source.matrix_world.copy()
    tag_output(output, source, kind)
    return output


def clear_tagged_outputs() -> int:
    clear_sampling_cache()
    outputs = [output for output in bpy.data.objects if is_tool_output(output)]
    for output in outputs:
        mesh = output.data if output.type == "MESH" else None
        bpy.data.objects.remove(output, do_unlink=True)
        if mesh is not None and mesh.users == 0:
            bpy.data.meshes.remove(mesh)
    for group in tuple(bpy.data.node_groups):
        if group.get(TOOL_TAG) == TOOL_ID:
            bpy.data.node_groups.remove(group, do_unlink=True)
    for material in tuple(bpy.data.materials):
        if material.get(TOOL_TAG) == TOOL_ID:
            bpy.data.materials.remove(material, do_unlink=True)
    return len(outputs)
